@echo off
rem Installs Lack for the current user (no administrator needed).
rem Put this file in the same folder as lack.exe, then double-click it.
setlocal
set "DEST=%LOCALAPPDATA%\Lack"

if not exist "%~dp0lack.exe" (
    echo lack.exe was not found next to this installer.
    echo Build it first with build-windows.bat, then run this again.
    pause
    exit /b 1
)

if not exist "%DEST%" mkdir "%DEST%"
copy /Y "%~dp0lack.exe" "%DEST%\lack.exe" >nul
copy /Y "%~dp0lack-run.bat" "%DEST%\lack-run.bat" >nul

rem Double-clicking a .lack or .lc file now runs it.
reg add "HKCU\Software\Classes\.lack" /ve /d "LackFile" /f >nul
reg add "HKCU\Software\Classes\.lc" /ve /d "LackFile" /f >nul
reg add "HKCU\Software\Classes\LackFile" /ve /d "Lack Program" /f >nul
reg add "HKCU\Software\Classes\LackFile\DefaultIcon" /ve /d "%DEST%\lack.exe,0" /f >nul
reg add "HKCU\Software\Classes\LackFile\shell\open\command" /ve /d "\"%DEST%\lack-run.bat\" \"%%1\"" /f >nul

echo.
echo Lack is installed in %DEST%
echo Double-click any .lack or .lc file to run it.
echo VS Code finds Lack automatically after this.
pause

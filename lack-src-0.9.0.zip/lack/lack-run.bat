@echo off
rem Runs a Lack file and keeps the window open so you can read the output.
"%~dp0lack.exe" run "%~1"
echo.
pause

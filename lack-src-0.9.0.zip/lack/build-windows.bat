@echo off
rem Builds lack.exe. Needs Rust from https://rustup.rs
cargo build --release || exit /b 1
copy /Y target\release\lack.exe lack.exe >nul
echo Built: %CD%\lack.exe
echo Next: double-click install-windows.bat
pause

@echo off
rem ONE-CLICK SETUP FOR WINDOWS
rem Double-click this file. It installs Rust if needed, builds Lack,
rem installs it, and makes .lack and .lc files run when double-clicked.
setlocal
cd /d "%~dp0"
echo === Lack setup ===

where cargo >nul 2>nul
if errorlevel 1 (
    echo Rust is not installed. Downloading the Rust installer...
    curl.exe -sSfL -o "%TEMP%\rustup-init.exe" https://win.rustup.rs/x86_64
    if errorlevel 1 (
        echo Could not download Rust. Check your internet connection and run setup again.
        pause
        exit /b 1
    )
    echo Installing Rust. If asked, choose "1" for the default install.
    "%TEMP%\rustup-init.exe" -y
    set "PATH=%USERPROFILE%\.cargo\bin;%PATH%"
)

where cargo >nul 2>nul
if errorlevel 1 (
    echo Rust did not install correctly. Restart this setup after restarting your PC.
    pause
    exit /b 1
)

echo Building Lack (this takes a few minutes the first time)...
cargo build --release
if errorlevel 1 (
    echo Build failed. Copy the error text and send it to get help.
    pause
    exit /b 1
)

set "DEST=%LOCALAPPDATA%\Lack"
if not exist "%DEST%" mkdir "%DEST%"
copy /Y target\release\lack.exe "%DEST%\lack.exe" >nul
copy /Y lack-run.bat "%DEST%\lack-run.bat" >nul

rem Double-clicking a .lack or .lc file runs it in a window that stays open.
reg add "HKCU\Software\Classes\.lack" /ve /d "LackFile" /f >nul
reg add "HKCU\Software\Classes\.lc" /ve /d "LackFile" /f >nul
reg add "HKCU\Software\Classes\LackFile" /ve /d "Lack Program" /f >nul
reg add "HKCU\Software\Classes\LackFile\DefaultIcon" /ve /d "%DEST%\lack.exe,0" /f >nul
reg add "HKCU\Software\Classes\LackFile\shell\open\command" /ve /d "\"%DEST%\lack-run.bat\" \"%%1\"" /f >nul

rem Add the install folder to your PATH so "lack" works in any terminal.
powershell -NoProfile -Command "$p=[Environment]::GetEnvironmentVariable('Path','User'); if ($p -notlike '*%DEST%*') { [Environment]::SetEnvironmentVariable('Path', ($p + ';%DEST%'), 'User') }"

echo.
echo === Lack is installed in %DEST% ===
echo Double-click any .lack or .lc file to run it.
echo Open a new terminal and type: lack --version
pause

use crate::ast::*;
use crate::lexer::{Tok, Token};
use std::rc::Rc;

pub struct Parser {
    t: Vec<Token>,
    p: usize,
}

type R<T> = Result<T, String>;

impl Parser {
    pub fn new(t: Vec<Token>) -> Self {
        Parser { t, p: 0 }
    }

    fn peek(&self) -> &Tok {
        &self.t[self.p].tok
    }
    fn line(&self) -> usize {
        self.t[self.p].line
    }
    fn nl(&self) -> bool {
        self.t[self.p].nl_before
    }
    fn next(&mut self) -> Tok {
        let t = self.t[self.p].tok.clone();
        if self.p < self.t.len() - 1 {
            self.p += 1;
        }
        t
    }
    fn is_op(&self, o: &str) -> bool {
        matches!(self.peek(), Tok::Op(x) if *x == o)
    }
    fn is_kw(&self, k: &str) -> bool {
        matches!(self.peek(), Tok::Ident(x) if x == k)
    }
    fn eat_op(&mut self, o: &str) -> bool {
        if self.is_op(o) {
            self.next();
            true
        } else {
            false
        }
    }
    fn expect(&mut self, o: &str) -> R<()> {
        if self.eat_op(o) {
            Ok(())
        } else {
            Err(format!("line {}: expected '{}', found {:?}", self.line(), o, self.peek()))
        }
    }
    fn ident(&mut self) -> R<String> {
        let line = self.line();
        match self.next() {
            Tok::Ident(s) => Ok(s),
            t => Err(format!("line {line}: expected name, found {t:?}")),
        }
    }

    pub fn program(&mut self) -> R<Vec<Stmt>> {
        let mut v = Vec::new();
        while *self.peek() != Tok::Eof {
            v.push(self.stmt()?);
        }
        Ok(v)
    }

    fn block(&mut self) -> R<Vec<Stmt>> {
        self.expect("{")?;
        let mut v = Vec::new();
        while !self.is_op("}") {
            if *self.peek() == Tok::Eof {
                return Err("unexpected end of file, missing '}'".into());
            }
            v.push(self.stmt()?);
        }
        self.expect("}")?;
        Ok(v)
    }

    fn func(&mut self) -> R<Rc<FnDef>> {
        let name = self.ident()?;
        self.expect("(")?;
        let mut params = Vec::new();
        while !self.is_op(")") {
            params.push(self.ident()?);
            if !self.eat_op(",") {
                break;
            }
        }
        self.expect(")")?;
        let body = self.block()?;
        Ok(Rc::new(FnDef { name, params, body }))
    }

    fn stmt(&mut self) -> R<Stmt> {
        if let Tok::Ident(k) = self.peek().clone() {
            match k.as_str() {
                "fn" => {
                    self.next();
                    return Ok(Stmt::Fn(self.func()?));
                }
                "if" => {
                    self.next();
                    return self.if_rest();
                }
                "while" => {
                    self.next();
                    let c = self.expr()?;
                    return Ok(Stmt::While(c, self.block()?));
                }
                "for" => {
                    let line = self.line();
                    self.next();
                    let v = self.ident()?;
                    if !self.is_kw("in") {
                        return Err(format!("line {}: expected 'in'", self.line()));
                    }
                    self.next();
                    let it = self.expr()?;
                    return Ok(Stmt::For(v, it, self.block()?, line));
                }
                "extern" => {
                    let line = self.line();
                    self.next();
                    let lib = match self.next() {
                        Tok::Str(s) => s,
                        t => return Err(format!("line {line}: extern needs a library name in quotes, found {t:?}")),
                    };
                    if !self.is_kw("fn") {
                        return Err(format!("line {line}: expected 'fn' after extern library"));
                    }
                    self.next();
                    let name = self.ident()?;
                    self.expect("(")?;
                    let mut params = Vec::new();
                    while !self.is_op(")") {
                        let t = self.ident()?;
                        if !matches!(t.as_str(), "int" | "float" | "str") {
                            return Err(format!("line {line}: unknown parameter type '{t}' (use int, float or str)"));
                        }
                        params.push(t);
                        if !self.eat_op(",") {
                            break;
                        }
                    }
                    self.expect(")")?;
                    let mut ret = "void".to_string();
                    if self.eat_op("->") {
                        ret = self.ident()?;
                        if !matches!(ret.as_str(), "int" | "float" | "str" | "void") {
                            return Err(format!("line {line}: unknown return type '{ret}' (use int, float, str or void)"));
                        }
                    }
                    return Ok(Stmt::Extern { lib, name, params, ret, line });
                }
                "import" | "include" => {
                    let line = self.line();
                    self.next();
                    return Ok(Stmt::Import(self.import_target()?, line));
                }
                "class" => {
                    self.next();
                    let name = self.ident()?;
                    self.expect("{")?;
                    let (mut fields, mut methods) = (Vec::new(), Vec::new());
                    while !self.is_op("}") {
                        if self.is_kw("fn") {
                            self.next();
                            methods.push(self.func()?);
                        } else {
                            let f = self.ident()?;
                            self.expect("=")?;
                            fields.push((f, self.expr()?));
                        }
                    }
                    self.expect("}")?;
                    return Ok(Stmt::Class { name, fields, methods });
                }
                "return" => {
                    self.next();
                    if self.nl() || self.is_op("}") {
                        return Ok(Stmt::Return(None));
                    }
                    return Ok(Stmt::Return(Some(self.expr()?)));
                }
                "break" => {
                    self.next();
                    return Ok(Stmt::Break);
                }
                "continue" => {
                    self.next();
                    return Ok(Stmt::Continue);
                }
                _ => {}
            }
        }
        let line = self.line();
        let e = self.expr()?;
        for op in ["=", "+=", "-=", "*=", "/=", "%="] {
            if self.is_op(op) {
                self.next();
                if !matches!(e, Expr::Var(..) | Expr::Member(..) | Expr::Index(..)) {
                    return Err(format!("line {line}: cannot assign to this expression"));
                }
                let value = self.expr()?;
                let op = if op == "=" { None } else { Some(&op[..1]) };
                let op: Option<&'static str> = op.map(|o| match o {
                    "+" => "+",
                    "-" => "-",
                    "*" => "*",
                    "/" => "/",
                    _ => "%",
                });
                return Ok(Stmt::Assign { target: e, op, value, line });
            }
        }
        Ok(Stmt::Expr(e))
    }

    // import util | import "lib/util.lack" | import "github.com/u/r/file" | #include <util>
    fn import_target(&mut self) -> R<String> {
        let line = self.line();
        match self.peek().clone() {
            Tok::Str(s) => {
                self.next();
                Ok(s)
            }
            Tok::Op("<") => {
                self.next();
                let mut name = String::new();
                loop {
                    match self.next() {
                        Tok::Op(">") => break,
                        Tok::Ident(s) => name.push_str(&s),
                        Tok::Op(".") => name.push('/'),
                        t => return Err(format!("line {line}: bad include name, found {t:?}")),
                    }
                }
                Ok(name)
            }
            Tok::Ident(_) => {
                let mut name = self.ident()?;
                while self.is_op(".") && !self.nl() {
                    self.next();
                    name.push('/');
                    name.push_str(&self.ident()?);
                }
                Ok(name)
            }
            t => Err(format!("line {line}: expected module name after import, found {t:?}")),
        }
    }

    fn if_rest(&mut self) -> R<Stmt> {
        let c = self.expr()?;
        let t = self.block()?;
        let mut e = Vec::new();
        if self.is_kw("else") {
            self.next();
            if self.is_kw("if") {
                self.next();
                e.push(self.if_rest()?);
            } else {
                e = self.block()?;
            }
        }
        Ok(Stmt::If(c, t, e))
    }

    pub fn expr(&mut self) -> R<Expr> {
        self.range()
    }

    fn range(&mut self) -> R<Expr> {
        let l = self.or()?;
        let line = self.line();
        for (o, inc) in [("..=", true), ("..", false)] {
            if self.is_op(o) {
                self.next();
                let r = self.or()?;
                return Ok(Expr::Range(Box::new(l), Box::new(r), inc, line));
            }
        }
        Ok(l)
    }

    fn bin(&mut self, ops: &[&'static str], lower: fn(&mut Self) -> R<Expr>) -> R<Expr> {
        let mut l = lower(self)?;
        loop {
            let line = self.line();
            let op = ops.iter().find(|o| self.is_op(o)).copied();
            match op {
                // a leading + or - on a new line starts a new statement
                Some(o) if !(self.nl() && (o == "-" || o == "+")) => {
                    self.next();
                    let r = lower(self)?;
                    l = Expr::Binary(o, Box::new(l), Box::new(r), line);
                }
                _ => return Ok(l),
            }
        }
    }

    fn or(&mut self) -> R<Expr> {
        self.bin(&["||"], Self::and)
    }
    fn and(&mut self) -> R<Expr> {
        self.bin(&["&&"], Self::eq)
    }
    fn eq(&mut self) -> R<Expr> {
        self.bin(&["==", "!="], Self::cmp)
    }
    fn cmp(&mut self) -> R<Expr> {
        self.bin(&["<=", ">=", "<", ">"], Self::add)
    }
    fn add(&mut self) -> R<Expr> {
        self.bin(&["+", "-"], Self::mul)
    }
    fn mul(&mut self) -> R<Expr> {
        self.bin(&["*", "/", "%"], Self::unary)
    }

    fn unary(&mut self) -> R<Expr> {
        let line = self.line();
        if self.eat_op("-") {
            return Ok(Expr::Unary("-", Box::new(self.unary()?), line));
        }
        if self.eat_op("!") {
            return Ok(Expr::Unary("!", Box::new(self.unary()?), line));
        }
        if self.is_kw("not") {
            self.next();
            return Ok(Expr::Unary("!", Box::new(self.unary()?), line));
        }
        self.postfix()
    }

    fn postfix(&mut self) -> R<Expr> {
        let mut e = self.primary()?;
        loop {
            let line = self.line();
            if self.is_op("(") && !self.nl() {
                self.next();
                let mut args = Vec::new();
                while !self.is_op(")") {
                    args.push(self.expr()?);
                    if !self.eat_op(",") {
                        break;
                    }
                }
                self.expect(")")?;
                e = Expr::Call(Box::new(e), args, line);
            } else if self.is_op("[") && !self.nl() {
                self.next();
                let i = self.expr()?;
                self.expect("]")?;
                e = Expr::Index(Box::new(e), Box::new(i), line);
            } else if self.is_op(".") {
                self.next();
                let n = self.ident()?;
                e = Expr::Member(Box::new(e), n, line);
            } else {
                return Ok(e);
            }
        }
    }

    fn interp_str(&self, s: &str, line: usize) -> R<Expr> {
        let fix = |x: &str| x.replace('\u{1}', "{").replace('\u{2}', "}");
        let cs: Vec<char> = s.chars().collect();
        let (mut parts, mut lit, mut i) = (Vec::<Expr>::new(), String::new(), 0);
        while i < cs.len() {
            if cs[i] == '{' {
                let (mut j, mut d) = (i + 1, 1);
                while j < cs.len() {
                    if cs[j] == '{' {
                        d += 1;
                    } else if cs[j] == '}' {
                        d -= 1;
                        if d == 0 {
                            break;
                        }
                    }
                    j += 1;
                }
                if j >= cs.len() {
                    return Err(format!("line {line}: unclosed '{{' in string (use \\{{ for a literal brace)"));
                }
                if !lit.is_empty() {
                    parts.push(Expr::Str(fix(&lit)));
                    lit.clear();
                }
                let inner: String = cs[i + 1..j].iter().collect();
                let toks = crate::lexer::lex(&inner).map_err(|e| format!("line {line}: {e}"))?;
                let e = Parser::new(toks).expr()?;
                parts.push(Expr::Call(Box::new(Expr::Var("str".into(), line)), vec![e], line));
                i = j + 1;
            } else {
                lit.push(cs[i]);
                i += 1;
            }
        }
        if !lit.is_empty() {
            parts.push(Expr::Str(fix(&lit)));
        }
        if parts.is_empty() {
            return Ok(Expr::Str(String::new()));
        }
        let mut it = parts.into_iter();
        let mut acc = it.next().unwrap();
        if !matches!(acc, Expr::Str(_)) {
            acc = Expr::Binary("+", Box::new(Expr::Str(String::new())), Box::new(acc), line);
        }
        for p in it {
            acc = Expr::Binary("+", Box::new(acc), Box::new(p), line);
        }
        Ok(acc)
    }

    fn primary(&mut self) -> R<Expr> {
        let line = self.line();
        match self.next() {
            Tok::Int(i) => Ok(Expr::Int(i)),
            Tok::Float(f) => Ok(Expr::Float(f)),
            Tok::Str(s) => self.interp_str(&s, line),
            Tok::Ident(s) => Ok(match s.as_str() {
                "true" => Expr::Bool(true),
                "false" => Expr::Bool(false),
                "nil" => Expr::Nil,
                _ => Expr::Var(s, line),
            }),
            Tok::Op("(") => {
                let e = self.expr()?;
                self.expect(")")?;
                Ok(e)
            }
            Tok::Op("{") => {
                let mut v = Vec::new();
                while !self.is_op("}") {
                    let key = match self.peek().clone() {
                        Tok::Ident(n) if matches!(self.t[self.p + 1].tok, Tok::Op(":")) => {
                            self.next();
                            Expr::Str(n)
                        }
                        _ => self.expr()?,
                    };
                    self.expect(":")?;
                    let val = self.expr()?;
                    v.push((key, val));
                    if !self.eat_op(",") && !self.nl() {
                        break;
                    }
                }
                self.expect("}")?;
                Ok(Expr::Map(v))
            }
            Tok::Op("[") => {
                let mut v = Vec::new();
                while !self.is_op("]") {
                    v.push(self.expr()?);
                    if !self.eat_op(",") {
                        break;
                    }
                }
                self.expect("]")?;
                Ok(Expr::List(v))
            }
            t => Err(format!("line {line}: unexpected {t:?}")),
        }
    }
}

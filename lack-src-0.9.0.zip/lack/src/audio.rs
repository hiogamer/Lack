use rodio::buffer::SamplesBuffer;
use rodio::{DeviceSinkBuilder, MixerDeviceSink, Player};
use std::num::{NonZeroU16, NonZeroU32};

pub const RATE: u32 = 44_100;

/// A sine tone with short fades at both ends so it doesn't click.
pub fn tone_samples(freq: f32, ms: u64) -> Vec<f32> {
    let n = (RATE as u64 * ms / 1000) as usize;
    let fade = (RATE / 200) as usize;
    (0..n)
        .map(|i| {
            let t = i as f32 / RATE as f32;
            let env = if i < fade {
                i as f32 / fade as f32
            } else if n - i <= fade {
                (n - i) as f32 / fade as f32
            } else {
                1.0
            };
            0.3 * env * (2.0 * std::f32::consts::PI * freq * t).sin()
        })
        .collect()
}

/// Writes mono 16-bit WAV, which every operating system and most audio tools can open.
pub fn save_wav(path: &str, samples: &[f32]) -> std::io::Result<()> {
    let data_len = (samples.len() * 2) as u32;
    let mut out = Vec::with_capacity(44 + data_len as usize);
    out.extend(b"RIFF");
    out.extend((36 + data_len).to_le_bytes());
    out.extend(b"WAVE");
    out.extend(b"fmt ");
    out.extend(16u32.to_le_bytes());
    out.extend(1u16.to_le_bytes());
    out.extend(1u16.to_le_bytes());
    out.extend(RATE.to_le_bytes());
    out.extend((RATE * 2).to_le_bytes());
    out.extend(2u16.to_le_bytes());
    out.extend(16u16.to_le_bytes());
    out.extend(b"data");
    out.extend(data_len.to_le_bytes());
    for s in samples {
        out.extend(((s.clamp(-1.0, 1.0) * 32767.0) as i16).to_le_bytes());
    }
    std::fs::write(path, out)
}

pub struct Audio {
    _sink: MixerDeviceSink,
    player: Player,
}

impl Audio {
    pub fn open() -> Result<Audio, String> {
        let sink = DeviceSinkBuilder::open_default_sink().map_err(|e| format!("no sound device: {e}"))?;
        let player = Player::connect_new(sink.mixer());
        Ok(Audio { _sink: sink, player })
    }

    /// Queues a tone; tones play one after another in the background.
    pub fn tone(&self, freq: f32, ms: u64) {
        let samples = tone_samples(freq, ms);
        self.player.append(SamplesBuffer::new(
            NonZeroU16::new(1).unwrap(),
            NonZeroU32::new(RATE).unwrap(),
            samples,
        ));
    }

    /// Blocks until all queued tones have finished.
    pub fn wait(&self) {
        self.player.sleep_until_end();
    }
}

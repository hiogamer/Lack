mod ai;
mod ml;
mod ast;
mod audio;
mod gfx;
mod interp;
mod lexer;
mod parser;

use std::io::Write;
use std::path::Path;
use std::process::exit;

fn run_source(src: &str, file: Option<&Path>) -> Result<(), String> {
    let toks = lexer::lex(src)?;
    let prog = parser::Parser::new(toks).program()?;
    let out = std::io::stdout();
    let mut w = std::io::BufWriter::new(out);
    let mut it = interp::Interp::new(
        prog,
        Box::new(move |s: &str| {
            let _ = w.write_all(s.as_bytes());
            let _ = w.flush();
        }),
    );
    if let Some(f) = file {
        let dir = f.parent().filter(|p| !p.as_os_str().is_empty()).unwrap_or(Path::new("."));
        it.base = std::fs::canonicalize(dir).unwrap_or(dir.to_path_buf());
        if let Ok(c) = std::fs::canonicalize(f) {
            it.loaded.insert(c);
        }
    }
    it.run()
}

fn repl() {
    use std::io::BufRead;
    println!("Lack 0.9.0 REPL - Ctrl-D to exit");
    let mut it = interp::Interp::new(
        Vec::new(),
        Box::new(|s: &str| {
            print!("{s}");
            let _ = std::io::stdout().flush();
        }),
    );
    let stdin = std::io::stdin();
    let mut buf = String::new();
    loop {
        print!("{}", if buf.is_empty() { ">> " } else { ".. " });
        let _ = std::io::stdout().flush();
        let mut line = String::new();
        if stdin.lock().read_line(&mut line).unwrap_or(0) == 0 {
            break;
        }
        buf.push_str(&line);
        let open = buf.matches('{').count() as i64 - buf.matches('}').count() as i64;
        if open > 0 {
            continue;
        }
        let r = lexer::lex(&buf)
            .and_then(|t| parser::Parser::new(t).program())
            .and_then(|p| it.repl_exec(p));
        match r {
            Ok(v) => v.iter().for_each(|x| println!("{x}")),
            Err(e) => eprintln!("error: {e}"),
        }
        buf.clear();
    }
}

fn find_main() -> Option<String> {
    ["src/main.lack", "main.lack"].iter().find(|p| Path::new(p).exists()).map(|s| s.to_string())
}

fn main() {
    // Deep Lack recursion needs more stack than the OS default.
    let child = std::thread::Builder::new().stack_size(512 << 20).spawn(real_main).expect("spawn");
    if child.join().is_err() {
        exit(70);
    }
}

fn real_main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    match args.first().map(|s| s.as_str()) {
        None => repl(),
        Some("run") => {
            let file = match args.get(1).cloned().or_else(find_main) {
                Some(f) => f,
                None => {
                    eprintln!("usage: lack run [file.lack]");
                    exit(2);
                }
            };
            let src = std::fs::read_to_string(&file).unwrap_or_else(|e| {
                eprintln!("error: cannot read {file}: {e}");
                exit(2)
            });
            if let Err(e) = run_source(&src, Some(Path::new(&file))) {
                eprintln!("error: {e}");
                exit(1);
            }
        }
        Some("new") => {
            let name = args.get(1).unwrap_or_else(|| {
                eprintln!("usage: lack new <name>");
                exit(2)
            });
            std::fs::create_dir_all(format!("{name}/src")).expect("create dir");
            std::fs::write(
                format!("{name}/src/main.lack"),
                "fn greet(name) {\n    print(\"Hello \" + name)\n}\n\ngreet(\"World\")\n",
            )
            .expect("write file");
            println!("Created project {name}");
        }
        Some("--version") => println!("lack 0.9.0"),
        Some(f) if Path::new(f).is_file() => {
            let src = std::fs::read_to_string(f).unwrap_or_else(|e| {
                eprintln!("error: cannot read {f}: {e}");
                exit(2)
            });
            if let Err(e) = run_source(&src, Some(Path::new(f))) {
                eprintln!("error: {e}");
                exit(1);
            }
        }
        Some(c) => {
            eprintln!("unknown command '{c}'. commands: run, new");
            exit(2);
        }
    }
}

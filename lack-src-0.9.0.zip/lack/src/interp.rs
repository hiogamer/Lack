use crate::ast::*;
use std::cell::RefCell;
use enigo::{Button, Coordinate, Direction, Enigo, Key as EKey, Keyboard, Mouse, Settings};
use libffi::middle::{Arg, Cif, CodePtr, Type};
use libloading::Library;
use std::collections::{HashMap, HashSet};
use std::ffi::{c_char, c_void, CStr, CString};
use std::path::{Path, PathBuf};
use std::fmt;
use std::rc::Rc;

pub struct ClassDef {
    name: String,
    fields: Vec<(String, *const Expr)>,
    methods: HashMap<String, Rc<FnDef>>,
    _prog: Rc<Vec<Stmt>>,
}

pub struct Object {
    class: Rc<ClassDef>,
    fields: HashMap<String, Value>,
}

#[derive(Clone)]
pub enum Value {
    Nil,
    Int(i64),
    Float(f64),
    Bool(bool),
    Str(Rc<str>),
    List(Rc<RefCell<Vec<Value>>>),
    Map(Rc<RefCell<Vec<(String, Value)>>>),
    Func(Rc<FnDef>, Env),
    Bound(Rc<FnDef>, Rc<RefCell<Object>>),
    Class(Rc<ClassDef>),
    Object(Rc<RefCell<Object>>),
    Builtin(&'static str),
    Method(Box<Value>, &'static str),
    Native(Rc<NativeFn>),
}

impl fmt::Display for Value {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            Value::Nil => write!(f, "nil"),
            Value::Int(i) => write!(f, "{i}"),
            Value::Float(x) => {
                if x.fract() == 0.0 && x.abs() < 1e15 {
                    write!(f, "{x:.1}")
                } else {
                    write!(f, "{x}")
                }
            }
            Value::Bool(b) => write!(f, "{b}"),
            Value::Str(s) => write!(f, "{s}"),
            Value::List(l) => {
                write!(f, "[")?;
                for (i, v) in l.borrow().iter().enumerate() {
                    if i > 0 {
                        write!(f, ", ")?;
                    }
                    match v {
                        Value::Str(s) => write!(f, "\"{s}\"")?,
                        v => write!(f, "{v}")?,
                    }
                }
                write!(f, "]")
            }
            Value::Map(m) => {
                write!(f, "{{")?;
                for (i, (k, v)) in m.borrow().iter().enumerate() {
                    if i > 0 {
                        write!(f, ", ")?;
                    }
                    match v {
                        Value::Str(s) => write!(f, "{k}: \"{s}\"")?,
                        v => write!(f, "{k}: {v}")?,
                    }
                }
                write!(f, "}}")
            }
            Value::Func(d, _) | Value::Bound(d, _) => write!(f, "<fn {}>", d.name),
            Value::Class(c) => write!(f, "<class {}>", c.name),
            Value::Object(o) => write!(f, "<{} object>", o.borrow().class.name),
            Value::Builtin(n) => write!(f, "<builtin {n}>"),
            Value::Method(_, n) => write!(f, "<method {n}>"),
            Value::Native(n) => write!(f, "<extern fn {}>", n.name),
        }
    }
}

pub struct Scope {
    vars: HashMap<String, Value>,
    parent: Option<Env>,
    this: Option<Rc<RefCell<Object>>>,
}
pub type Env = Rc<RefCell<Scope>>;

fn new_env(parent: Option<Env>, this: Option<Rc<RefCell<Object>>>) -> Env {
    Rc::new(RefCell::new(Scope { vars: HashMap::new(), parent, this }))
}

pub enum Ctrl {
    Return(Value),
    Break,
    Continue,
    Err(String),
}
type R<T> = Result<T, Ctrl>;

fn err<T>(line: usize, m: impl Into<String>) -> R<T> {
    Err(Ctrl::Err(format!("line {line}: {}", m.into())))
}

const BUILTINS: &[&str] = &[
    "print", "len", "str", "int", "float", "sqrt", "abs", "push", "type", "min", "http_get", "links",
    "input", "random", "window", "clear", "rect", "circle", "present", "key_down", "mouse", "mouse_down",
    "sleep", "rgb", "key_press", "type_text", "mouse_move", "mouse_click",
    "font", "text", "text_width", "image", "button", "tone", "sound_wait", "save_tone",
    "camera3d", "box3d", "plane3d", "tri3d", "sin_deg", "cos_deg", "save_image",
    "round_rect", "line", "icon", "collide", "save_text", "load_text", "ai", "ai_chat", "page_text", "screenshot", "mlp_train", "mlp_predict",
];

fn fnums(a: &[Value]) -> Option<Vec<f32>> {
    a.iter()
        .map(|v| match v {
            Value::Int(i) => Some(*i as f32),
            Value::Float(f) => Some(*f as f32),
            _ => None,
        })
        .collect()
}

fn enigo_key(n: &str) -> Option<EKey> {
    let n = n.to_ascii_lowercase();
    Some(match n.as_str() {
        "enter" => EKey::Return,
        "escape" => EKey::Escape,
        "space" => EKey::Space,
        "tab" => EKey::Tab,
        "backspace" => EKey::Backspace,
        "left" => EKey::LeftArrow,
        "right" => EKey::RightArrow,
        "up" => EKey::UpArrow,
        "down" => EKey::DownArrow,
        "shift" => EKey::Shift,
        "ctrl" => EKey::Control,
        s if s.chars().count() == 1 => EKey::Unicode(s.chars().next().unwrap()),
        _ => return None,
    })
}

pub struct NativeFn {
    name: String,
    code: CodePtr,
    params: Vec<String>,
    ret: String,
    _lib: Rc<Library>,
}

enum Slot {
    I(i64),
    F(f64),
    P(*const c_char),
}

fn ctype(t: &str) -> Type {
    match t {
        "int" => Type::i64(),
        "float" => Type::f64(),
        "str" => Type::pointer(),
        _ => Type::void(),
    }
}

pub struct Interp {
    pub globals: Env,
    prog: Rc<Vec<Stmt>>,
    pub out: Box<dyn FnMut(&str)>,
    depth: usize,
    pub base: PathBuf,
    pub loaded: HashSet<PathBuf>,
    keep: Vec<Rc<Vec<Stmt>>>,
    libs: HashMap<String, Rc<Library>>,
    rng: u64,
    pub gfx: Option<crate::gfx::Gfx>,
    input_dev: Option<Enigo>,
    assets: crate::gfx::Assets,
    audio: Option<crate::audio::Audio>,
}

impl Interp {
    pub fn new(prog: Vec<Stmt>, out: Box<dyn FnMut(&str)>) -> Self {
        let globals = new_env(None, None);
        for b in BUILTINS {
            globals.borrow_mut().vars.insert(b.to_string(), Value::Builtin(b));
        }
        Interp {
            globals,
            prog: Rc::new(prog),
            out,
            depth: 0,
            base: std::env::current_dir().unwrap_or_else(|_| PathBuf::from(".")),
            loaded: HashSet::new(),
            keep: Vec::new(),
            libs: HashMap::new(),
            gfx: None,
            input_dev: None,
            assets: Default::default(),
            audio: None,
            rng: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map(|d| d.as_nanos() as u64)
                .unwrap_or(0x9E37_79B9_7F4A_7C15)
                | 1,
        }
    }

    pub fn run(&mut self) -> Result<(), String> {
        let prog = self.prog.clone();
        let g = self.globals.clone();
        // SAFETY of lifetimes: `prog` is kept alive by Rc in self and ClassDefs.
        match self.exec_block(&prog, &g) {
            Ok(()) => Ok(()),
            Err(Ctrl::Err(e)) => Err(e),
            Err(Ctrl::Return(_)) => Err("'return' outside function".into()),
            Err(_) => Err("'break'/'continue' outside loop".into()),
        }
    }

    pub fn repl_exec(&mut self, prog: Vec<Stmt>) -> Result<Vec<String>, String> {
        let prog = Rc::new(prog);
        self.keep.push(prog.clone());
        let g = self.globals.clone();
        let mut shown = Vec::new();
        for s in prog.iter() {
            let r = match s {
                Stmt::Expr(e) => self.eval(e, &g).map(|v| {
                    if !matches!(v, Value::Nil) {
                        shown.push(v.to_string())
                    }
                }),
                _ => self.exec(s, &g),
            };
            if let Err(c) = r {
                return Err(match c {
                    Ctrl::Err(e) => e,
                    _ => "return/break/continue outside function or loop".into(),
                });
            }
        }
        Ok(shown)
    }

    // Runs another file's top-level code in the global scope (like C++ #include).
    // Each file runs once, so circular or repeated imports are safe.
    fn import(&mut self, target: &str, line: usize) -> R<()> {
        let path = self.resolve_module(target).map_err(|e| Ctrl::Err(format!("line {line}: {e}")))?;
        let key = std::fs::canonicalize(&path).unwrap_or(path.clone());
        if !self.loaded.insert(key.clone()) {
            return Ok(());
        }
        let src = std::fs::read_to_string(&key)
            .map_err(|e| Ctrl::Err(format!("line {line}: cannot read {}: {e}", key.display())))?;
        let prog = crate::lexer::lex(&src)
            .and_then(|t| crate::parser::Parser::new(t).program())
            .map_err(|e| Ctrl::Err(format!("in {}: {e}", key.display())))?;
        let prog = Rc::new(prog);
        self.keep.push(prog.clone());
        let dir = key.parent().unwrap_or(Path::new(".")).to_path_buf();
        let saved = std::mem::replace(&mut self.base, dir);
        let g = self.globals.clone();
        let r = self.exec_block(&prog, &g);
        self.base = saved;
        r
    }

    fn resolve_module(&self, t: &str) -> Result<PathBuf, String> {
        let home = home_dir();
        if let Some(rest) = t.strip_prefix("github.com/") {
            let parts: Vec<&str> = rest.splitn(3, '/').collect();
            if parts.len() < 2 {
                return Err(format!("bad github import '{t}', use github.com/user/repo[/file]"));
            }
            let (user, repo) = (parts[0], parts[1]);
            let cache = PathBuf::from(&home).join(".lack/cache/github.com").join(user).join(repo);
            if !cache.exists() {
                std::fs::create_dir_all(cache.parent().unwrap()).map_err(|e| e.to_string())?;
                let ok = std::process::Command::new("git")
                    .args(["clone", "--depth", "1"])
                    .arg(format!("https://github.com/{user}/{repo}"))
                    .arg(&cache)
                    .status()
                    .map_err(|e| format!("cannot run git (install git to use github imports): {e}"))?
                    .success();
                if !ok {
                    return Err(format!("git clone of github.com/{user}/{repo} failed"));
                }
            }
            let rel = parts.get(2).copied().unwrap_or("");
            return find_file(&cache.join(rel))
                .ok_or_else(|| format!("'{t}' has no matching .lack file in the repository"));
        }
        let dirs = [
            self.base.clone(),
            self.base.join("lack_modules"),
            PathBuf::from(&home).join(".lack/packages"),
        ];
        for d in &dirs {
            if let Some(p) = find_file(&d.join(t)) {
                return Ok(p);
            }
        }
        let searched: Vec<String> = dirs.iter().map(|d| d.display().to_string()).collect();
        Err(format!("module '{t}' not found (searched: {})", searched.join(", ")))
    }

    fn font_ref(&mut self, line: usize) -> R<&fontdue::Font> {
        if self.assets.font.is_none() {
            let f = crate::gfx::load_default_font().map_err(|e| Ctrl::Err(format!("line {line}: {e}")))?;
            self.assets.font = Some(f);
        }
        Ok(self.assets.font.as_ref().unwrap())
    }

    fn gfx_font(&mut self, line: usize) -> R<(&mut crate::gfx::Gfx, &fontdue::Font)> {
        self.font_ref(line)?;
        let font = self.assets.font.as_ref().unwrap();
        match self.gfx.as_mut() {
            Some(g) => Ok((g, font)),
            None => err(line, "open a window first with window(width, height, title)"),
        }
    }

    fn draw_image(&mut self, line: usize, path: &str, x: i64, y: i64, size: Option<(i64, i64)>) -> R<()> {
        if !self.assets.images.contains_key(path) {
            let img = image::open(path)
                .map_err(|e| Ctrl::Err(format!("line {line}: cannot load image {path}: {e}")))?
                .to_rgba8();
            self.assets.images.insert(path.to_string(), img);
        }
        let img = self.assets.images.get(path).unwrap();
        match self.gfx.as_mut() {
            Some(g) => {
                g.image(img, x, y, size);
                Ok(())
            }
            None => err(line, "open a window first with window(width, height, title)"),
        }
    }

    fn ensure_audio(&mut self, line: usize) -> R<()> {
        if self.audio.is_none() {
            let a = crate::audio::Audio::open().map_err(|e| Ctrl::Err(format!("line {line}: {e}")))?;
            self.audio = Some(a);
        }
        Ok(())
    }

    fn gfx_mut(&mut self, line: usize) -> R<&mut crate::gfx::Gfx> {
        match self.gfx.as_mut() {
            Some(g) => Ok(g),
            None => err(line, "open a window first with window(width, height, title)"),
        }
    }

    fn input_dev(&mut self, line: usize) -> R<&mut Enigo> {
        if self.input_dev.is_none() {
            let e = Enigo::new(&Settings::default())
                .map_err(|e| Ctrl::Err(format!("line {line}: keyboard/mouse control unavailable: {e}")))?;
            self.input_dev = Some(e);
        }
        Ok(self.input_dev.as_mut().unwrap())
    }

    fn read_input(&mut self, prompt: &str) -> Value {
        (self.out)(prompt);
        let mut line = String::new();
        let _ = std::io::stdin().read_line(&mut line);
        Value::Str(line.trim_end_matches(|c| c == '\n' || c == '\r').into())
    }

    fn next_rand(&mut self) -> u64 {
        let mut x = self.rng;
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        self.rng = x;
        x
    }

    fn declare_extern(
        &mut self,
        lib: &str,
        name: &str,
        params: &[String],
        ret: &str,
        line: usize,
        env: &Env,
    ) -> R<()> {
        let rc = match self.libs.get(lib) {
            Some(l) => l.clone(),
            None => {
                let l = unsafe { Library::new(lib) }
                    .map_err(|e| Ctrl::Err(format!("line {line}: cannot load library '{lib}': {e}")))?;
                let rc = Rc::new(l);
                self.libs.insert(lib.to_string(), rc.clone());
                rc
            }
        };
        let ptr = unsafe {
            let sym = rc
                .get::<*mut c_void>(name.as_bytes())
                .map_err(|e| Ctrl::Err(format!("line {line}: '{name}' not found in {lib}: {e}")))?;
            *sym
        };
        let nf = NativeFn {
            name: name.to_string(),
            code: CodePtr::from_ptr(ptr as *const c_void),
            params: params.to_vec(),
            ret: ret.to_string(),
            _lib: rc,
        };
        env.borrow_mut().vars.insert(name.to_string(), Value::Native(Rc::new(nf)));
        Ok(())
    }

    fn call_native(&self, f: &NativeFn, args: Vec<Value>, line: usize) -> R<Value> {
        if args.len() != f.params.len() {
            return err(line, format!("{}() expects {} args, got {}", f.name, f.params.len(), args.len()));
        }
        let mut keep_alive: Vec<CString> = Vec::new();
        let mut slots: Vec<Slot> = Vec::new();
        for (ty, v) in f.params.iter().zip(args.iter()) {
            slots.push(match (ty.as_str(), v) {
                ("int", Value::Int(i)) => Slot::I(*i),
                ("float", Value::Float(x)) => Slot::F(*x),
                ("float", Value::Int(i)) => Slot::F(*i as f64),
                ("str", Value::Str(s)) => {
                    let c = CString::new(s.as_bytes())
                        .map_err(|_| Ctrl::Err(format!("line {line}: string argument contains a NUL byte")))?;
                    let p = c.as_ptr();
                    keep_alive.push(c);
                    Slot::P(p)
                }
                _ => return err(line, format!("{}(): argument must be {ty}", f.name)),
            });
        }
        let cargs: Vec<Arg> = slots
            .iter()
            .map(|s| match s {
                Slot::I(i) => Arg::new(i),
                Slot::F(x) => Arg::new(x),
                Slot::P(p) => Arg::new(p),
            })
            .collect();
        let cif = Cif::new(f.params.iter().map(|p| ctype(p)), ctype(&f.ret));
        let out = unsafe {
            match f.ret.as_str() {
                "int" => Value::Int(cif.call::<i64>(f.code, &cargs)),
                "float" => Value::Float(cif.call::<f64>(f.code, &cargs)),
                "str" => {
                    let p = cif.call::<*const c_char>(f.code, &cargs);
                    if p.is_null() {
                        Value::Nil
                    } else {
                        Value::Str(CStr::from_ptr(p).to_string_lossy().into_owned().into())
                    }
                }
                _ => {
                    cif.call::<()>(f.code, &cargs);
                    Value::Nil
                }
            }
        };
        drop(keep_alive);
        Ok(out)
    }

    fn lookup(&self, env: &Env, name: &str) -> Option<Value> {
        let mut cur = Some(env.clone());
        while let Some(e) = cur {
            let s = e.borrow();
            if let Some(v) = s.vars.get(name) {
                return Some(v.clone());
            }
            if let Some(t) = &s.this {
                if let Some(v) = t.borrow().fields.get(name) {
                    return Some(v.clone());
                }
            }
            cur = s.parent.clone();
        }
        None
    }

    fn assign(&self, env: &Env, name: &str, val: Value) {
        let mut cur = Some(env.clone());
        while let Some(e) = cur {
            {
                let mut s = e.borrow_mut();
                if s.vars.contains_key(name) {
                    s.vars.insert(name.to_string(), val);
                    return;
                }
                if let Some(t) = &s.this {
                    if t.borrow().fields.contains_key(name) {
                        t.borrow_mut().fields.insert(name.to_string(), val);
                        return;
                    }
                }
            }
            let p = e.borrow().parent.clone();
            cur = p;
        }
        env.borrow_mut().vars.insert(name.to_string(), val);
    }

    fn exec_block(&mut self, b: &[Stmt], env: &Env) -> R<()> {
        for s in b {
            self.exec(s, env)?;
        }
        Ok(())
    }

    fn exec(&mut self, s: &Stmt, env: &Env) -> R<()> {
        match s {
            Stmt::Expr(e) => {
                self.eval(e, env)?;
            }
            Stmt::Assign { target, op, value, line } => {
                let mut v = self.eval(value, env)?;
                if let Some(o) = op {
                    let cur = self.eval(target, env)?;
                    v = binop(o, cur, v, *line)?;
                }
                match target {
                    Expr::Var(n, _) => self.assign(env, n, v),
                    Expr::Member(o, n, l) => match self.eval(o, env)? {
                        Value::Object(ob) => {
                            ob.borrow_mut().fields.insert(n.clone(), v);
                        }
                        _ => return err(*l, "can only set fields on objects"),
                    },
                    Expr::Index(o, i, l) => {
                        let (c, i) = (self.eval(o, env)?, self.eval(i, env)?);
                        match (c, i) {
                            (Value::List(li), Value::Int(i)) => {
                                let mut li = li.borrow_mut();
                                let n = li.len() as i64;
                                if i < 0 || i >= n {
                                    return err(*l, format!("index {i} out of range (len {n})"));
                                }
                                li[i as usize] = v;
                            }
                            (Value::Map(m), k) => {
                                let key = k.to_string();
                                let mut m = m.borrow_mut();
                                match m.iter_mut().find(|(x, _)| *x == key) {
                                    Some(slot) => slot.1 = v,
                                    None => m.push((key, v)),
                                }
                            }
                            _ => return err(*l, "bad index assignment"),
                        }
                    }
                    _ => unreachable!(),
                }
            }
            Stmt::If(c, t, e) => {
                if truthy(&self.eval(c, env)?) {
                    self.exec_block(t, &new_env(Some(env.clone()), None))?;
                } else {
                    self.exec_block(e, &new_env(Some(env.clone()), None))?;
                }
            }
            Stmt::While(c, b) => {
                while truthy(&self.eval(c, env)?) {
                    match self.exec_block(b, &new_env(Some(env.clone()), None)) {
                        Err(Ctrl::Break) => break,
                        Err(Ctrl::Continue) | Ok(()) => {}
                        Err(e) => return Err(e),
                    }
                }
            }
            Stmt::For(var, it, b, line) => {
                let items: Vec<Value> = match self.eval(it, env)? {
                    Value::List(l) => l.borrow().clone(),
                    Value::Map(m) => m.borrow().iter().map(|(k, _)| Value::Str(k.as_str().into())).collect(),
                    Value::Str(s) => s.chars().map(|c| Value::Str(c.to_string().into())).collect(),
                    _ => return err(*line, "can only loop over a range, list or string"),
                };
                for v in items {
                    let e = new_env(Some(env.clone()), None);
                    e.borrow_mut().vars.insert(var.clone(), v);
                    match self.exec_block(b, &e) {
                        Err(Ctrl::Break) => break,
                        Err(Ctrl::Continue) | Ok(()) => {}
                        Err(e) => return Err(e),
                    }
                }
            }
            Stmt::Fn(d) => {
                env.borrow_mut().vars.insert(d.name.clone(), Value::Func(d.clone(), env.clone()));
            }
            Stmt::Class { name, fields, methods } => {
                let c = ClassDef {
                    name: name.clone(),
                    fields: fields.iter().map(|(n, e)| (n.clone(), e as *const Expr)).collect(),
                    methods: methods.iter().map(|m| (m.name.clone(), m.clone())).collect(),
                    _prog: self.prog.clone(),
                };
                env.borrow_mut().vars.insert(name.clone(), Value::Class(Rc::new(c)));
            }
            Stmt::Return(e) => {
                let v = match e {
                    Some(e) => self.eval(e, env)?,
                    None => Value::Nil,
                };
                return Err(Ctrl::Return(v));
            }
            Stmt::Import(t, l) => self.import(t, *l)?,
            Stmt::Extern { lib, name, params, ret, line } => {
                self.declare_extern(lib, name, params, ret, *line, env)?
            }
            Stmt::Break => return Err(Ctrl::Break),
            Stmt::Continue => return Err(Ctrl::Continue),
        }
        Ok(())
    }

    fn eval(&mut self, e: &Expr, env: &Env) -> R<Value> {
        Ok(match e {
            Expr::Int(i) => Value::Int(*i),
            Expr::Float(f) => Value::Float(*f),
            Expr::Bool(b) => Value::Bool(*b),
            Expr::Str(s) => Value::Str(s.as_str().into()),
            Expr::Nil => Value::Nil,
            Expr::Var(n, l) => match self.lookup(env, n) {
                Some(v) => v,
                None => return err(*l, format!("undefined variable '{n}'")),
            },
            Expr::Map(items) => {
                let mut o: Vec<(String, Value)> = Vec::new();
                for (k, v) in items {
                    let key = self.eval(k, env)?.to_string();
                    let val = self.eval(v, env)?;
                    match o.iter_mut().find(|(x, _)| *x == key) {
                        Some(slot) => slot.1 = val,
                        None => o.push((key, val)),
                    }
                }
                Value::Map(Rc::new(RefCell::new(o)))
            }
            Expr::List(v) => {
                let mut o = Vec::new();
                for x in v {
                    o.push(self.eval(x, env)?);
                }
                Value::List(Rc::new(RefCell::new(o)))
            }
            Expr::Range(a, b, inc, l) => match (self.eval(a, env)?, self.eval(b, env)?) {
                (Value::Int(a), Value::Int(b)) => {
                    let end = if *inc { b + 1 } else { b };
                    Value::List(Rc::new(RefCell::new((a..end).map(Value::Int).collect())))
                }
                _ => return err(*l, "range bounds must be integers"),
            },
            Expr::Unary(op, x, l) => {
                let v = self.eval(x, env)?;
                match (*op, v) {
                    ("-", Value::Int(i)) => Value::Int(-i),
                    ("-", Value::Float(f)) => Value::Float(-f),
                    ("!", v) => Value::Bool(!truthy(&v)),
                    _ => return err(*l, "bad operand for unary '-'"),
                }
            }
            Expr::Binary(op, a, b, l) => {
                if *op == "&&" || *op == "||" {
                    let av = self.eval(a, env)?;
                    return Ok(if (*op == "&&") == truthy(&av) { self.eval(b, env)? } else { av });
                }
                let (x, y) = (self.eval(a, env)?, self.eval(b, env)?);
                binop(op, x, y, *l)?
            }
            Expr::Index(o, i, l) => match (self.eval(o, env)?, self.eval(i, env)?) {
                (Value::List(li), Value::Int(i)) => {
                    let li = li.borrow();
                    let n = li.len() as i64;
                    let k = if i < 0 { i + n } else { i };
                    if k < 0 || k >= n {
                        return err(*l, format!("index {i} out of range (len {n})"));
                    }
                    li[k as usize].clone()
                }
                (Value::Map(m), k) => {
                    let key = k.to_string();
                    let found = m.borrow().iter().find(|(x, _)| *x == key).map(|(_, v)| v.clone());
                    match found {
                        Some(v) => v,
                        None => return err(*l, format!("key '{key}' not found")),
                    }
                }
                (Value::Str(s), Value::Int(i)) => match s.chars().nth(i.max(0) as usize) {
                    Some(c) if i >= 0 => Value::Str(c.to_string().into()),
                    _ => return err(*l, "string index out of range"),
                },
                _ => return err(*l, "value is not indexable with that index"),
            },
            Expr::Member(o, n, l) => match self.eval(o, env)? {
                Value::Object(ob) => {
                    if let Some(v) = ob.borrow().fields.get(n) {
                        return Ok(v.clone());
                    }
                    let m = ob.borrow().class.methods.get(n).cloned();
                    match m {
                        Some(m) => Value::Bound(m, ob.clone()),
                        None => return err(*l, format!("no field or method '{n}'")),
                    }
                }
                v @ (Value::List(_) | Value::Str(_) | Value::Map(_)) => {
                    let name: &'static str = match n.as_str() {
                        "push" => "push",
                        "len" => "len",
                        "upper" => "upper",
                        "lower" => "lower",
                        "pop" => "pop",
                        "has" => "has",
                        "keys" => "keys",
                        "values" => "values",
                        _ => return err(*l, format!("no method '{n}'")),
                    };
                    Value::Method(Box::new(v), name)
                }
                _ => return err(*l, format!("cannot read '{n}' from this value")),
            },
            Expr::Call(c, args, l) => {
                let f = self.eval(c, env)?;
                let mut a = Vec::new();
                for x in args {
                    a.push(self.eval(x, env)?);
                }
                self.call(f, a, *l)?
            }
        })
    }

    fn call(&mut self, f: Value, args: Vec<Value>, line: usize) -> R<Value> {
        Ok(match f {
            Value::Func(d, clo) => self.call_fn(&d, args, new_env(Some(clo), None), line)?,
            Value::Bound(d, ob) => {
                let e = new_env(Some(self.globals.clone()), Some(ob));
                self.call_fn(&d, args, e, line)?
            }
            Value::Class(c) => {
                let ob = Rc::new(RefCell::new(Object { class: c.clone(), fields: HashMap::new() }));
                for (n, e) in &c.fields {
                    // SAFETY: the expression lives in the program kept alive by `c._prog`.
                    let e: &Expr = unsafe { &**e };
                    let g = self.globals.clone();
                    let v = self.eval(e, &g)?;
                    ob.borrow_mut().fields.insert(n.clone(), v);
                }
                if let Some(init) = c.methods.get("init").cloned() {
                    let e = new_env(Some(self.globals.clone()), Some(ob.clone()));
                    self.call_fn(&init, args, e, line)?;
                } else if !args.is_empty() {
                    return err(line, format!("{} takes no arguments", c.name));
                }
                Value::Object(ob)
            }
            Value::Builtin(n) => self.builtin(n, args, line)?,
            Value::Native(nf) => self.call_native(&nf, args, line)?,
            Value::Method(recv, n) => match (*recv, n) {
                (Value::List(l), "push") if args.len() == 1 => {
                    l.borrow_mut().push(args[0].clone());
                    Value::Nil
                }
                (Value::List(l), "pop") => match l.borrow_mut().pop() {
                    Some(v) => v,
                    None => return err(line, "pop from empty list"),
                },
                (Value::Map(m), "has") if args.len() == 1 => {
                    let k = args[0].to_string();
                    Value::Bool(m.borrow().iter().any(|(x, _)| *x == k))
                }
                (Value::Map(m), "keys") => Value::List(Rc::new(RefCell::new(
                    m.borrow().iter().map(|(k, _)| Value::Str(k.as_str().into())).collect(),
                ))),
                (Value::Map(m), "values") => Value::List(Rc::new(RefCell::new(
                    m.borrow().iter().map(|(_, v)| v.clone()).collect(),
                ))),
                (Value::Map(m), "len") => Value::Int(m.borrow().len() as i64),
                (Value::List(l), "len") => Value::Int(l.borrow().len() as i64),
                (Value::Str(s), "len") => Value::Int(s.chars().count() as i64),
                (Value::Str(s), "upper") => Value::Str(s.to_uppercase().into()),
                (Value::Str(s), "lower") => Value::Str(s.to_lowercase().into()),
                _ => return err(line, format!("bad call to method '{n}'")),
            },
            _ => return err(line, "value is not callable"),
        })
    }

    fn call_fn(&mut self, d: &Rc<FnDef>, args: Vec<Value>, env: Env, line: usize) -> R<Value> {
        if args.len() != d.params.len() {
            return err(
                line,
                format!("{}() expects {} args, got {}", d.name, d.params.len(), args.len()),
            );
        }
        if self.depth > 2000 {
            return err(line, "stack overflow (recursion too deep)");
        }
        for (p, a) in d.params.iter().zip(args) {
            env.borrow_mut().vars.insert(p.clone(), a);
        }
        self.depth += 1;
        let r = self.exec_block(&d.body, &env);
        self.depth -= 1;
        match r {
            Ok(()) => Ok(Value::Nil),
            Err(Ctrl::Return(v)) => Ok(v),
            Err(e) => Err(e),
        }
    }

    fn builtin(&mut self, n: &str, a: Vec<Value>, line: usize) -> R<Value> {
        Ok(match (n, a.as_slice()) {
            ("print", args) => {
                let s: Vec<String> = args.iter().map(|v| v.to_string()).collect();
                (self.out)(&format!("{}\n", s.join(" ")));
                Value::Nil
            }
            ("len", [Value::List(l)]) => Value::Int(l.borrow().len() as i64),
            ("len", [Value::Map(m)]) => Value::Int(m.borrow().len() as i64),
            ("len", [Value::Str(s)]) => Value::Int(s.chars().count() as i64),
            ("str", [v]) => Value::Str(v.to_string().into()),
            ("int", [Value::Int(i)]) => Value::Int(*i),
            ("int", [Value::Float(f)]) => Value::Int(*f as i64),
            ("int", [Value::Str(s)]) => match s.trim().parse() {
                Ok(i) => Value::Int(i),
                Err(_) => return err(line, format!("cannot convert \"{s}\" to int")),
            },
            ("float", [Value::Int(i)]) => Value::Float(*i as f64),
            ("float", [Value::Float(f)]) => Value::Float(*f),
            ("sqrt", [Value::Int(i)]) => Value::Float((*i as f64).sqrt()),
            ("sqrt", [Value::Float(f)]) => Value::Float(f.sqrt()),
            ("abs", [Value::Int(i)]) => Value::Int(i.abs()),
            ("abs", [Value::Float(f)]) => Value::Float(f.abs()),
            ("push", [Value::List(l), v]) => {
                l.borrow_mut().push(v.clone());
                Value::Nil
            }
            ("min", [Value::Int(x), Value::Int(y)]) => Value::Int(*x.min(y)),
            ("input", []) => self.read_input(""),
            ("input", [Value::Str(p)]) => {
                let p = p.to_string();
                self.read_input(&p)
            }
            ("random", [Value::Int(lo), Value::Int(hi)]) if lo <= hi => {
                let span = (*hi as i128) - (*lo as i128) + 1;
                let r = (self.next_rand() as i128) % span;
                Value::Int((*lo as i128 + r) as i64)
            }
            ("window", [Value::Int(w), Value::Int(h), Value::Str(t)]) if *w > 0 && *h > 0 && *w * *h <= 1 << 26 => {
                let t = t.to_string();
                let g = crate::gfx::Gfx::open(*w as usize, *h as usize, &t)
                    .map_err(|e| Ctrl::Err(format!("line {line}: window: {e}")))?;
                // A file named icon.ico next to the program becomes the window icon.
                let icon = self.base.join("icon.ico");
                if icon.is_file() {
                    crate::gfx::set_window_icon(g.win.get_window_handle(), &icon);
                }
                self.gfx = Some(g);
                Value::Nil
            }
            ("clear", [Value::Int(c)]) => {
                self.gfx_mut(line)?.fill(*c as u32);
                Value::Nil
            }
            ("rect", [Value::Int(x), Value::Int(y), Value::Int(w), Value::Int(h), Value::Int(c)]) => {
                self.gfx_mut(line)?.rect(*x, *y, *w, *h, *c as u32);
                Value::Nil
            }
            ("circle", [Value::Int(x), Value::Int(y), Value::Int(r), Value::Int(c)]) => {
                self.gfx_mut(line)?.circle(*x, *y, *r, *c as u32);
                Value::Nil
            }
            ("present", []) => match self.gfx_mut(line)?.present() {
                Ok(open) => Value::Bool(open),
                Err(e) => return err(line, format!("present: {e}")),
            },
            ("key_down", [Value::Str(k)]) => {
                let k = k.to_string();
                let key = match crate::gfx::key_from_name(&k) {
                    Some(key) => key,
                    None => return err(line, format!("unknown key '{k}'")),
                };
                Value::Bool(self.gfx_mut(line)?.win.is_key_down(key))
            }
            ("mouse", []) => match self.gfx_mut(line)?.mouse() {
                Some((x, y)) => Value::List(Rc::new(RefCell::new(vec![
                    Value::Int(x as i64),
                    Value::Int(y as i64),
                ]))),
                None => Value::Nil,
            },
            ("mouse_down", []) => Value::Bool(self.gfx_mut(line)?.mouse_down()),
            ("sleep", [Value::Int(ms)]) => {
                std::thread::sleep(std::time::Duration::from_millis((*ms).max(0) as u64));
                Value::Nil
            }
            ("rgb", [Value::Int(r), Value::Int(g), Value::Int(b)]) => {
                Value::Int((((*r & 255) << 16) | ((*g & 255) << 8) | (*b & 255)) as i64)
            }
            ("key_press", [Value::Str(k)]) => {
                let k = k.to_string();
                let key = match enigo_key(&k) {
                    Some(key) => key,
                    None => return err(line, format!("unknown key '{k}'")),
                };
                let dev = self.input_dev(line)?;
                dev.key(key, Direction::Press)
                    .map_err(|e| Ctrl::Err(format!("line {line}: key_press: {e}")))?;
                std::thread::sleep(std::time::Duration::from_millis(50));
                dev.key(key, Direction::Release)
                    .map_err(|e| Ctrl::Err(format!("line {line}: key_press: {e}")))?;
                Value::Nil
            }
            ("type_text", [Value::Str(s)]) => {
                let s = s.to_string();
                self.input_dev(line)?
                    .text(&s)
                    .map_err(|e| Ctrl::Err(format!("line {line}: type_text: {e}")))?;
                Value::Nil
            }
            ("mouse_move", [Value::Int(x), Value::Int(y)]) => {
                self.input_dev(line)?
                    .move_mouse(*x as i32, *y as i32, Coordinate::Abs)
                    .map_err(|e| Ctrl::Err(format!("line {line}: mouse_move: {e}")))?;
                Value::Nil
            }
            ("mouse_click", []) => {
                // Hold briefly so that programs polling the mouse each frame see the click.
                let dev = self.input_dev(line)?;
                dev.button(Button::Left, Direction::Press)
                    .map_err(|e| Ctrl::Err(format!("line {line}: mouse_click: {e}")))?;
                std::thread::sleep(std::time::Duration::from_millis(50));
                dev.button(Button::Left, Direction::Release)
                    .map_err(|e| Ctrl::Err(format!("line {line}: mouse_click: {e}")))?;
                Value::Nil
            }
            ("font", [Value::Str(p)]) => {
                let p = p.to_string();
                let bytes = std::fs::read(&p).map_err(|e| Ctrl::Err(format!("line {line}: cannot read font {p}: {e}")))?;
                self.assets.font = Some(
                    fontdue::Font::from_bytes(bytes, fontdue::FontSettings::default())
                        .map_err(|e| Ctrl::Err(format!("line {line}: bad font {p}: {e}")))?,
                );
                Value::Nil
            }
            ("text", [Value::Int(x), Value::Int(y), Value::Str(s), Value::Int(px), Value::Int(c)]) => {
                let s = s.to_string();
                let (g, font) = self.gfx_font(line)?;
                g.text(font, *x, *y, &s, *px as f32, *c as u32);
                Value::Nil
            }
            ("text_width", [Value::Str(s), Value::Int(px)]) => {
                let font = self.font_ref(line)?;
                Value::Int(crate::gfx::text_width(font, s, *px as f32))
            }
            ("image", [Value::Str(p), Value::Int(x), Value::Int(y)]) => {
                let p = p.to_string();
                self.draw_image(line, &p, *x, *y, None)?;
                Value::Nil
            }
            ("image", [Value::Str(p), Value::Int(x), Value::Int(y), Value::Int(w), Value::Int(h)]) => {
                let p = p.to_string();
                self.draw_image(line, &p, *x, *y, Some((*w, *h)))?;
                Value::Nil
            }
            ("button", [Value::Int(x), Value::Int(y), Value::Int(w), Value::Int(h), Value::Str(label)]) => {
                let label = label.to_string();
                let (g, font) = self.gfx_font(line)?;
                Value::Bool(g.button(font, *x, *y, *w, *h, &label))
            }
            ("round_rect", [Value::Int(x), Value::Int(y), Value::Int(w), Value::Int(h), Value::Int(r), Value::Int(c)]) => {
                self.gfx_mut(line)?.round_rect(*x, *y, *w, *h, *r, *c as u32);
                Value::Nil
            }
            ("line", [Value::Int(x0), Value::Int(y0), Value::Int(x1), Value::Int(y1), Value::Int(t), Value::Int(c)]) => {
                self.gfx_mut(line)?.line(*x0, *y0, *x1, *y1, *t, *c as u32);
                Value::Nil
            }
            ("icon", [Value::Str(name), Value::Int(x), Value::Int(y), Value::Int(size)]) => {
                let name = name.to_string();
                if let Err(e) = self.gfx_mut(line)?.icon(&name, *x, *y, *size) {
                    return err(line, format!("icon: {e}"));
                }
                Value::Nil
            }
            ("collide", [Value::Int(ax), Value::Int(ay), Value::Int(aw), Value::Int(ah), Value::Int(bx), Value::Int(by), Value::Int(bw), Value::Int(bh)]) => {
                Value::Bool(*ax < *bx + *bw && *bx < *ax + *aw && *ay < *by + *bh && *by < *ay + *ah)
            }
            ("save_text", [Value::Str(p), Value::Str(text)]) => {
                let (p, text) = (p.to_string(), text.to_string());
                if let Err(e) = std::fs::write(&p, text) {
                    return err(line, format!("save_text: {e}"));
                }
                Value::Nil
            }
            ("load_text", [Value::Str(p)]) => match std::fs::read_to_string(p.to_string()) {
                Ok(text) => Value::Str(text.into()),
                Err(_) => Value::Nil,
            },
            ("ai", [Value::Str(p)]) => {
                let p = p.to_string();
                match crate::ai::ask(&p) {
                    Ok(text) => Value::Str(text.into()),
                    Err(e) => return err(line, format!("ai: {e}")),
                }
            }
            ("ai_chat", [Value::List(l)]) => {
                let items: Vec<String> = l.borrow().iter().map(|v| v.to_string()).collect();
                if items.is_empty() || items.len() % 2 == 0 {
                    return err(line, "ai_chat: give a list that alternates your messages and the replies, and ends with your message".to_string());
                }
                let turns: Vec<(String, String)> = items
                    .into_iter()
                    .enumerate()
                    .map(|(i, text)| (if i % 2 == 0 { "user" } else { "assistant" }.to_string(), text))
                    .collect();
                match crate::ai::chat(&turns) {
                    Ok(text) => Value::Str(text.into()),
                    Err(e) => return err(line, format!("ai_chat: {e}")),
                }
            }
            ("page_text", [Value::Str(u)]) => {
                let url = u.to_string();
                match std::process::Command::new("curl")
                    .args(["-sSL", "--max-time", "30", "--", &url])
                    .output()
                {
                    Ok(o) if o.status.success() => {
                        Value::Str(html_to_text(&String::from_utf8_lossy(&o.stdout)).into())
                    }
                    Ok(o) => {
                        return err(line, format!("page_text failed: {}", String::from_utf8_lossy(&o.stderr).trim()))
                    }
                    Err(e) => return err(line, format!("page_text needs curl installed: {e}")),
                }
            }
            ("screenshot", [Value::Str(p)]) => {
                let path = p.to_string();
                if let Err(e) = crate::gfx::screenshot(&path) {
                    return err(line, format!("screenshot: {e}"));
                }
                Value::Nil
            }
            ("mlp_train", [xs @ Value::List(_), ys @ Value::List(_), Value::Int(h), Value::Int(ep), lr]) => {
                let lr = match lr {
                    Value::Float(f) => *f,
                    Value::Int(i) => *i as f64,
                    _ => return err(line, "mlp_train: the learning rate must be a number".to_string()),
                };
                match crate::ml::train(xs, ys, *h as usize, *ep as usize, lr) {
                    Ok(model) => model,
                    Err(e) => return err(line, format!("mlp_train: {e}")),
                }
            }
            ("mlp_predict", [model, xs]) => match crate::ml::predict(model, xs) {
                Ok(out) => out,
                Err(e) => return err(line, format!("mlp_predict: {e}")),
            },
            ("tone", [Value::Int(f), Value::Int(ms)]) => {
                self.ensure_audio(line)?;
                if let Some(a) = &self.audio {
                    a.tone(*f as f32, (*ms).max(0) as u64);
                }
                Value::Nil
            }
            ("sound_wait", []) => {
                if let Some(a) = &self.audio {
                    a.wait();
                }
                Value::Nil
            }
            ("save_tone", [Value::Str(p), Value::Int(f), Value::Int(ms)]) => {
                let p = p.to_string();
                let samples = crate::audio::tone_samples(*f as f32, (*ms).max(0) as u64);
                crate::audio::save_wav(&p, &samples)
                    .map_err(|e| Ctrl::Err(format!("line {line}: cannot write {p}: {e}")))?;
                Value::Nil
            }
            ("camera3d", a) if a.len() == 5 && fnums(a).is_some() => {
                let v = fnums(a).unwrap();
                self.gfx_mut(line)?.cam = crate::gfx::Camera {
                    pos: [v[0], v[1], v[2]],
                    yaw: v[3].to_radians(),
                    pitch: v[4].to_radians(),
                };
                Value::Nil
            }
            ("box3d", a) if a.len() == 7 && matches!(a[6], Value::Int(_)) && fnums(&a[..6]).is_some() => {
                let v = fnums(&a[..6]).unwrap();
                let c = if let Value::Int(c) = a[6] { c as u32 } else { 0 };
                self.gfx_mut(line)?.box3d(v[0], v[1], v[2], v[3], v[4], v[5], c);
                Value::Nil
            }
            ("plane3d", a) if a.len() == 3 && matches!(a[2], Value::Int(_)) && fnums(&a[..2]).is_some() => {
                let v = fnums(&a[..2]).unwrap();
                let c = if let Value::Int(c) = a[2] { c as u32 } else { 0 };
                self.gfx_mut(line)?.plane3d(v[0], v[1], c);
                Value::Nil
            }
            ("tri3d", a) if a.len() == 10 && matches!(a[9], Value::Int(_)) && fnums(&a[..9]).is_some() => {
                let v = fnums(&a[..9]).unwrap();
                let c = if let Value::Int(c) = a[9] { c as u32 } else { 0 };
                self.gfx_mut(line)?.tri3d([v[0], v[1], v[2]], [v[3], v[4], v[5]], [v[6], v[7], v[8]], c);
                Value::Nil
            }
            ("sin_deg", a) if a.len() == 1 && fnums(a).is_some() => {
                Value::Float(fnums(a).unwrap()[0].to_radians().sin() as f64)
            }
            ("cos_deg", a) if a.len() == 1 && fnums(a).is_some() => {
                Value::Float(fnums(a).unwrap()[0].to_radians().cos() as f64)
            }
            ("save_image", [Value::Str(p)]) => {
                let p = p.to_string();
                self.gfx_mut(line)?
                    .save(&p)
                    .map_err(|e| Ctrl::Err(format!("line {line}: save_image: {e}")))?;
                Value::Nil
            }
            ("http_get", [Value::Str(u)]) => {
                let url = u.to_string();
                match std::process::Command::new("curl")
                    .args(["-sSL", "--max-time", "30", "--", &url])
                    .output()
                {
                    Ok(o) if o.status.success() => {
                        Value::Str(String::from_utf8_lossy(&o.stdout).into_owned().into())
                    }
                    Ok(o) => {
                        return err(line, format!("http_get failed: {}", String::from_utf8_lossy(&o.stderr).trim()))
                    }
                    Err(e) => return err(line, format!("http_get needs curl installed: {e}")),
                }
            }
            ("links", [Value::Str(h)]) => {
                let mut out = Vec::new();
                let mut rest: &str = h;
                while let Some(i) = rest.find("href=") {
                    rest = &rest[i + 5..];
                    let q = match rest.chars().next() {
                        Some(c @ ('"' | '\'')) => c,
                        _ => continue,
                    };
                    rest = &rest[1..];
                    match rest.find(q) {
                        Some(j) => {
                            out.push(Value::Str(decode_entities(&rest[..j]).into()));
                            rest = &rest[j + 1..];
                        }
                        None => break,
                    }
                }
                Value::List(Rc::new(RefCell::new(out)))
            }
            ("type", [v]) => Value::Str(
                match v {
                    Value::Nil => "nil",
                    Value::Int(_) => "int",
                    Value::Float(_) => "float",
                    Value::Bool(_) => "bool",
                    Value::Str(_) => "str",
                    Value::List(_) => "list",
                    Value::Map(_) => "map",
                    Value::Object(_) => "object",
                    _ => "function",
                }
                .into(),
            ),
            _ => return err(line, format!("bad arguments to {n}()")),
        })
    }
}

fn home_dir() -> String {
    std::env::var("HOME")
        .or_else(|_| std::env::var("USERPROFILE"))
        .unwrap_or_else(|_| ".".into())
}

// Removes every <tag>...</tag> block (used for script and style).
fn strip_blocks(html: &str, tag: &str) -> String {
    let lower = html.to_ascii_lowercase();
    let open = format!("<{tag}");
    let close = format!("</{tag}>");
    let mut out = String::new();
    let mut pos = 0;
    while let Some(i) = lower[pos..].find(&open) {
        let start = pos + i;
        out.push_str(&html[pos..start]);
        match lower[start..].find(&close) {
            Some(j) => pos = start + j + close.len(),
            None => {
                pos = html.len();
                break;
            }
        }
    }
    out.push_str(&html[pos..]);
    out
}

// Turns a web page into plain text: drops scripts, styles and tags, decodes entities.
fn html_to_text(html: &str) -> String {
    let s = strip_blocks(&strip_blocks(html, "script"), "style");
    let mut text = String::with_capacity(s.len());
    let mut in_tag = false;
    for c in s.chars() {
        match c {
            '<' => {
                in_tag = true;
                text.push(' ');
            }
            '>' if in_tag => in_tag = false,
            c if !in_tag => text.push(c),
            _ => {}
        }
    }
    decode_entities(&text).split_whitespace().collect::<Vec<_>>().join(" ")
}

fn decode_entities(s: &str) -> String {
    if !s.contains('&') {
        return s.to_string();
    }
    s.replace("&amp;", "&")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
        .replace("&apos;", "'")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
}

fn find_file(base: &Path) -> Option<PathBuf> {
    let mut with_ext = base.as_os_str().to_owned();
    with_ext.push(".lack");
    [base.to_path_buf(), PathBuf::from(with_ext), base.join("main.lack")]
        .into_iter()
        .find(|p| p.is_file())
}

fn truthy(v: &Value) -> bool {
    !matches!(v, Value::Nil | Value::Bool(false) | Value::Int(0))
}

fn num(v: &Value) -> Option<f64> {
    match v {
        Value::Int(i) => Some(*i as f64),
        Value::Float(f) => Some(*f),
        _ => None,
    }
}

fn binop(op: &str, a: Value, b: Value, line: usize) -> R<Value> {
    use Value::*;
    Ok(match (op, &a, &b) {
        ("+", Str(x), _) => Str(format!("{x}{b}").into()),
        ("+", _, Str(y)) => Str(format!("{a}{y}").into()),
        ("+", List(x), List(y)) => {
            let mut v = x.borrow().clone();
            v.extend(y.borrow().iter().cloned());
            List(Rc::new(RefCell::new(v)))
        }
        ("==", ..) => Bool(equal(&a, &b)),
        ("!=", ..) => Bool(!equal(&a, &b)),
        (_, Int(x), Int(y)) => match op {
            "+" => Int(x.checked_add(*y).ok_or_else(|| Ctrl::Err(format!("line {line}: integer overflow")))?),
            "-" => Int(x.checked_sub(*y).ok_or_else(|| Ctrl::Err(format!("line {line}: integer overflow")))?),
            "*" => Int(x.checked_mul(*y).ok_or_else(|| Ctrl::Err(format!("line {line}: integer overflow")))?),
            "/" | "%" if *y == 0 => return err(line, "division by zero"),
            "/" => Int(x.checked_div(*y).ok_or_else(|| Ctrl::Err(format!("line {line}: integer overflow")))?),
            "%" => Int(x.checked_rem(*y).ok_or_else(|| Ctrl::Err(format!("line {line}: integer overflow")))?),
            "<" => Bool(x < y),
            ">" => Bool(x > y),
            "<=" => Bool(x <= y),
            ">=" => Bool(x >= y),
            _ => return err(line, "bad operator"),
        },
        _ => match (num(&a), num(&b)) {
            (Some(x), Some(y)) => match op {
                "+" => Float(x + y),
                "-" => Float(x - y),
                "*" => Float(x * y),
                "/" => Float(x / y),
                "%" => Float(x % y),
                "<" => Bool(x < y),
                ">" => Bool(x > y),
                "<=" => Bool(x <= y),
                ">=" => Bool(x >= y),
                _ => return err(line, "bad operator"),
            },
            _ => return err(line, format!("cannot apply '{op}' to these values")),
        },
    })
}

fn equal(a: &Value, b: &Value) -> bool {
    use Value::*;
    match (a, b) {
        (Nil, Nil) => true,
        (Bool(x), Bool(y)) => x == y,
        (Str(x), Str(y)) => x == y,
        (List(x), List(y)) => {
            let (x, y) = (x.borrow(), y.borrow());
            x.len() == y.len() && x.iter().zip(y.iter()).all(|(p, q)| equal(p, q))
        }
        _ => match (num(a), num(b)) {
            (Some(x), Some(y)) => x == y,
            _ => false,
        },
    }
}

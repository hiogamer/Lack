use std::rc::Rc;

#[derive(Debug)]
pub enum Expr {
    Int(i64),
    Float(f64),
    Bool(bool),
    Str(String),
    Nil,
    Var(String, usize),
    Binary(&'static str, Box<Expr>, Box<Expr>, usize),
    Unary(&'static str, Box<Expr>, usize),
    Call(Box<Expr>, Vec<Expr>, usize),
    Member(Box<Expr>, String, usize),
    Index(Box<Expr>, Box<Expr>, usize),
    List(Vec<Expr>),
    Map(Vec<(Expr, Expr)>),
    Range(Box<Expr>, Box<Expr>, bool, usize),
}

#[derive(Debug)]
pub struct FnDef {
    pub name: String,
    pub params: Vec<String>,
    pub body: Vec<Stmt>,
}

#[derive(Debug)]
pub enum Stmt {
    Expr(Expr),
    Assign { target: Expr, op: Option<&'static str>, value: Expr, line: usize },
    If(Expr, Vec<Stmt>, Vec<Stmt>),
    While(Expr, Vec<Stmt>),
    For(String, Expr, Vec<Stmt>, usize),
    Fn(Rc<FnDef>),
    Import(String, usize),
    Extern { lib: String, name: String, params: Vec<String>, ret: String, line: usize },
    Class { name: String, fields: Vec<(String, Expr)>, methods: Vec<Rc<FnDef>> },
    Return(Option<Expr>),
    Break,
    Continue,
}

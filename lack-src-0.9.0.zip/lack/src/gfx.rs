use fontdue::{Font, FontSettings};
use image::RgbaImage;
use minifb::{Key as K, MouseButton, MouseMode, Window, WindowOptions};
use std::collections::HashMap;
use std::time::Duration;

/// Fonts and decoded images, kept separate from the window so they can be used headless.
#[derive(Default)]
pub struct Assets {
    pub font: Option<Font>,
    pub images: HashMap<String, RgbaImage>,
}

const FONT_CANDIDATES: [&str; 6] = [
    r"C:\Windows\Fonts\arial.ttf",
    "/System/Library/Fonts/Supplemental/Arial.ttf",
    "/Library/Fonts/Arial.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
    "/usr/share/fonts/TTF/DejaVuSans.ttf",
];

pub fn load_default_font() -> Result<Font, String> {
    for p in FONT_CANDIDATES {
        if let Ok(bytes) = std::fs::read(p) {
            return Font::from_bytes(bytes, FontSettings::default()).map_err(|e| format!("bad font {p}: {e}"));
        }
    }
    Err("no font found on this system; load one with font(\"path/to/font.ttf\")".into())
}

pub fn text_width(font: &Font, s: &str, px: f32) -> i64 {
    s.chars().map(|c| font.metrics(c, px).advance_width).sum::<f32>().round() as i64
}

/// Mixes color `src` over `dst` with alpha `a` (0-255).
fn blend(dst: u32, src: u32, a: u32) -> u32 {
    let mix = |sh: u32| {
        let s = (src >> sh) & 255;
        let d = (dst >> sh) & 255;
        (s * a + d * (255 - a)) / 255
    };
    (mix(16) << 16) | (mix(8) << 8) | mix(0)
}

/// Camera for 3D drawing. Angles are in radians. yaw 0 looks along +z; positive pitch looks up.
#[derive(Clone, Copy, Default)]
pub struct Camera {
    pub pos: [f32; 3],
    pub yaw: f32,
    pub pitch: f32,
}

pub struct Gfx {
    pub win: Window,
    pub buf: Vec<u32>,
    pub w: usize,
    pub h: usize,
    depth: Vec<f32>,
    pub cam: Camera,
    prev_down: bool,
}

/// Sets the title-bar and taskbar icon of a window from an .ico file (Windows only).
#[cfg(windows)]
pub fn set_window_icon(hwnd: *mut std::ffi::c_void, path: &std::path::Path) {
    use std::os::windows::ffi::OsStrExt;
    unsafe extern "system" {
        fn LoadImageW(hinst: *mut std::ffi::c_void, name: *const u16, kind: u32, cx: i32, cy: i32, flags: u32) -> *mut std::ffi::c_void;
        fn SendMessageW(hwnd: *mut std::ffi::c_void, msg: u32, wparam: usize, lparam: isize) -> isize;
    }
    const IMAGE_ICON: u32 = 1;
    const LR_LOADFROMFILE: u32 = 0x0010;
    const LR_DEFAULTSIZE: u32 = 0x0040;
    const WM_SETICON: u32 = 0x0080;
    let wide: Vec<u16> = path.as_os_str().encode_wide().chain(std::iter::once(0)).collect();
    unsafe {
        let icon = LoadImageW(std::ptr::null_mut(), wide.as_ptr(), IMAGE_ICON, 0, 0, LR_LOADFROMFILE | LR_DEFAULTSIZE);
        if !icon.is_null() {
            SendMessageW(hwnd, WM_SETICON, 1, icon as isize);
            SendMessageW(hwnd, WM_SETICON, 0, icon as isize);
        }
    }
}

/// Sets the window icon from an .ico file. Does nothing on other systems.
#[cfg(not(windows))]
pub fn set_window_icon(_hwnd: *mut std::ffi::c_void, _path: &std::path::Path) {}

impl Gfx {
    pub fn open(w: usize, h: usize, title: &str) -> Result<Gfx, String> {
        let mut win = Window::new(title, w, h, WindowOptions::default()).map_err(|e| e.to_string())?;
        win.limit_update_rate(Some(Duration::from_micros(16_600)));
        Ok(Gfx { win, buf: vec![0; w * h], w, h, depth: vec![0.0; w * h], cam: Camera::default(), prev_down: false })
    }

    fn put(&mut self, x: i64, y: i64, c: u32, a: u32) {
        if x < 0 || y < 0 || x >= self.w as i64 || y >= self.h as i64 {
            return;
        }
        let i = y as usize * self.w + x as usize;
        self.buf[i] = if a >= 255 { c } else { blend(self.buf[i], c, a) };
    }

    pub fn fill(&mut self, c: u32) {
        self.buf.fill(c);
        self.depth.fill(0.0);
    }

    /// Projects a world point to screen (x, y, 1/depth), or None if it is behind the camera.
    fn project(&self, p: [f32; 3]) -> Option<(f32, f32, f32)> {
        let c = self.cam;
        let r = [p[0] - c.pos[0], p[1] - c.pos[1], p[2] - c.pos[2]];
        let (cy, sy) = (c.yaw.cos(), c.yaw.sin());
        let x = r[0] * cy - r[2] * sy;
        let z1 = r[0] * sy + r[2] * cy;
        let (cp, sp) = (c.pitch.cos(), c.pitch.sin());
        let y = r[1] * cp - z1 * sp;
        let z = r[1] * sp + z1 * cp;
        if z < 0.05 {
            return None;
        }
        let f = (self.h as f32 / 2.0) / (30f32.to_radians()).tan();
        Some((self.w as f32 / 2.0 + x * f / z, self.h as f32 / 2.0 - y * f / z, 1.0 / z))
    }

    /// Draws one filled triangle in world coordinates with a depth test and simple lighting.
    pub fn tri3d(&mut self, a: [f32; 3], b: [f32; 3], c: [f32; 3], color: u32) {
        let (Some(pa), Some(pb), Some(pc)) = (self.project(a), self.project(b), self.project(c)) else {
            return;
        };
        let u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
        let v = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
        let n = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]];
        let len = (n[0] * n[0] + n[1] * n[1] + n[2] * n[2]).sqrt().max(1e-9);
        let l = [0.4f32, 0.8, -0.5];
        let ll = (l[0] * l[0] + l[1] * l[1] + l[2] * l[2]).sqrt();
        let dot = (n[0] * l[0] + n[1] * l[1] + n[2] * l[2]) / (len * ll);
        let shade = 0.35 + 0.65 * dot.abs();
        let ch = |sh: u32| (((((color >> sh) & 255) as f32) * shade).min(255.0)) as u32;
        let col = (ch(16) << 16) | (ch(8) << 8) | ch(0);

        let edge = |p: (f32, f32), q: (f32, f32), r: (f32, f32)| (r.0 - p.0) * (q.1 - p.1) - (r.1 - p.1) * (q.0 - p.0);
        let (p0, p1, p2) = ((pa.0, pa.1), (pb.0, pb.1), (pc.0, pc.1));
        let area = edge(p0, p1, p2);
        if area.abs() < 1e-6 {
            return;
        }
        let minx = pa.0.min(pb.0).min(pc.0).floor().max(0.0) as i64;
        let maxx = pa.0.max(pb.0).max(pc.0).ceil().min(self.w as f32 - 1.0) as i64;
        let miny = pa.1.min(pb.1).min(pc.1).floor().max(0.0) as i64;
        let maxy = pa.1.max(pb.1).max(pc.1).ceil().min(self.h as f32 - 1.0) as i64;
        for py in miny..=maxy {
            for px in minx..=maxx {
                let p = (px as f32 + 0.5, py as f32 + 0.5);
                let w0 = edge(p1, p2, p) / area;
                let w1 = edge(p2, p0, p) / area;
                let w2 = edge(p0, p1, p) / area;
                if w0 >= 0.0 && w1 >= 0.0 && w2 >= 0.0 {
                    let iz = w0 * pa.2 + w1 * pb.2 + w2 * pc.2;
                    let i = py as usize * self.w + px as usize;
                    if iz > self.depth[i] {
                        self.depth[i] = iz;
                        self.buf[i] = col;
                    }
                }
            }
        }
    }

    /// A solid box with its corner at (x, y, z), size w x h x d.
    pub fn box3d(&mut self, x: f32, y: f32, z: f32, w: f32, h: f32, d: f32, color: u32) {
        let c = [
            [x, y, z], [x + w, y, z], [x + w, y + h, z], [x, y + h, z],
            [x, y, z + d], [x + w, y, z + d], [x + w, y + h, z + d], [x, y + h, z + d],
        ];
        for f in [[0, 1, 2, 3], [5, 4, 7, 6], [4, 0, 3, 7], [1, 5, 6, 2], [3, 2, 6, 7], [4, 5, 1, 0]] {
            self.tri3d(c[f[0]], c[f[1]], c[f[2]], color);
            self.tri3d(c[f[0]], c[f[2]], c[f[3]], color);
        }
    }

    /// A flat square floor at height y, centered on (0, y, 0), half-width `half`.
    pub fn plane3d(&mut self, y: f32, half: f32, color: u32) {
        let a = [-half, y, -half];
        let b = [half, y, -half];
        let c = [half, y, half];
        let d = [-half, y, half];
        self.tri3d(a, b, c, color);
        self.tri3d(a, c, d, color);
    }

    pub fn save(&self, path: &str) -> Result<(), String> {
        let mut raw = Vec::with_capacity(self.w * self.h * 4);
        for &c in &self.buf {
            raw.extend([((c >> 16) & 255) as u8, ((c >> 8) & 255) as u8, (c & 255) as u8, 255]);
        }
        let img = image::RgbaImage::from_raw(self.w as u32, self.h as u32, raw)
            .ok_or_else(|| "bad image size".to_string())?;
        img.save(path).map_err(|e| e.to_string())
    }

    pub fn rect(&mut self, x: i64, y: i64, rw: i64, rh: i64, c: u32) {
        let (x0, y0) = (x.max(0), y.max(0));
        let (x1, y1) = ((x + rw).min(self.w as i64), (y + rh).min(self.h as i64));
        for yy in y0..y1 {
            let row = yy as usize * self.w;
            for xx in x0..x1 {
                self.buf[row + xx as usize] = c;
            }
        }
    }

    pub fn circle(&mut self, cx: i64, cy: i64, r: i64, c: u32) {
        for yy in (cy - r).max(0)..(cy + r + 1).min(self.h as i64) {
            for xx in (cx - r).max(0)..(cx + r + 1).min(self.w as i64) {
                let (dx, dy) = (xx - cx, yy - cy);
                if dx * dx + dy * dy <= r * r {
                    self.buf[yy as usize * self.w + xx as usize] = c;
                }
            }
        }
    }

    /// Filled rectangle with rounded corners; `r` is the corner radius in pixels.
    pub fn round_rect(&mut self, x: i64, y: i64, w: i64, h: i64, r: i64, c: u32) {
        let r = r.max(0).min(w / 2).min(h / 2);
        self.rect(x + r, y, w - 2 * r, h, c);
        self.rect(x, y + r, w, h - 2 * r, c);
        for (cx, cy) in [
            (x + r, y + r),
            (x + w - r - 1, y + r),
            (x + r, y + h - r - 1),
            (x + w - r - 1, y + h - r - 1),
        ] {
            self.circle(cx, cy, r, c);
        }
    }

    /// Straight line from (x0, y0) to (x1, y1), `thick` pixels wide.
    pub fn line(&mut self, x0: i64, y0: i64, x1: i64, y1: i64, thick: i64, c: u32) {
        let t = thick.max(1);
        let (dx, dy) = ((x1 - x0).abs(), -(y1 - y0).abs());
        let (sx, sy) = (if x0 < x1 { 1 } else { -1 }, if y0 < y1 { 1 } else { -1 });
        let (mut x, mut y, mut err) = (x0, y0, dx + dy);
        loop {
            self.rect(x - t / 2, y - t / 2, t, t, c);
            if x == x1 && y == y1 {
                break;
            }
            let e2 = 2 * err;
            if e2 >= dy {
                err += dy;
                x += sx;
            }
            if e2 <= dx {
                err += dx;
                y += sy;
            }
        }
    }

    /// Draws a built-in 8x8 pixel icon scaled to `size` pixels.
    pub fn icon(&mut self, name: &str, x: i64, y: i64, size: i64) -> Result<(), String> {
        let grid = icon_grid(name).ok_or_else(|| format!("unknown icon '{name}'"))?;
        let s = (size / 8).max(1);
        for (row, line) in grid.iter().enumerate() {
            for (col, ch) in line.chars().enumerate() {
                if let Some(c) = icon_color(ch) {
                    self.rect(x + col as i64 * s, y + row as i64 * s, s, s, c);
                }
            }
        }
        Ok(())
    }

    /// Draws text with its top-left corner at (x, y); `px` is the font size in pixels.
    pub fn text(&mut self, font: &Font, x: i64, y: i64, s: &str, px: f32, c: u32) {
        let ascent = font.horizontal_line_metrics(px).map(|m| m.ascent).unwrap_or(px * 0.8);
        let baseline = (y as f32 + ascent).round() as i64;
        let mut pen = x as f32;
        for ch in s.chars() {
            let (m, bmp) = font.rasterize(ch, px);
            let gx = pen.round() as i64 + m.xmin as i64;
            let gy = baseline - m.ymin as i64 - m.height as i64;
            for r in 0..m.height {
                for k in 0..m.width {
                    let a = bmp[r * m.width + k] as u32;
                    if a > 0 {
                        self.put(gx + k as i64, gy + r as i64, c, a);
                    }
                }
            }
            pen += m.advance_width;
        }
    }

    /// Draws an image at (x, y), optionally scaled to (w, h), with transparency.
    pub fn image(&mut self, img: &RgbaImage, x: i64, y: i64, size: Option<(i64, i64)>) {
        let (iw, ih) = img.dimensions();
        let (w, h) = size.unwrap_or((iw as i64, ih as i64));
        if w <= 0 || h <= 0 || iw == 0 || ih == 0 {
            return;
        }
        for dy in 0..h {
            for dx in 0..w {
                let sx = (dx as u64 * iw as u64 / w as u64) as u32;
                let sy = (dy as u64 * ih as u64 / h as u64) as u32;
                let p = img.get_pixel(sx, sy).0;
                let a = p[3] as u32;
                if a > 0 {
                    let c = ((p[0] as u32) << 16) | ((p[1] as u32) << 8) | p[2] as u32;
                    self.put(x + dx, y + dy, c, a);
                }
            }
        }
    }

    /// Draws a button and returns true on the frame the left mouse button is pressed over it.
    pub fn button(&mut self, font: &Font, x: i64, y: i64, w: i64, h: i64, label: &str) -> bool {
        let (mx, my) = self.mouse().map(|(a, b)| (a as i64, b as i64)).unwrap_or((-1, -1));
        let hover = mx >= x && mx < x + w && my >= y && my < y + h;
        let clicked = hover && self.mouse_down() && !self.prev_down;
        self.rect(x, y, w, h, 0x8AA2FF);
        self.rect(x + 2, y + 2, w - 4, h - 4, if hover { 0x3A4A7A } else { 0x262F52 });
        let px = (h as f32 * 0.5).max(8.0);
        let tw = text_width(font, label, px);
        self.text(font, x + (w - tw) / 2, y + (h - px as i64) / 2, label, px, 0xFFFFFF);
        clicked
    }

    /// Shows the frame. Returns Ok(false) once the user has closed the window.
    pub fn present(&mut self) -> Result<bool, String> {
        self.win.update_with_buffer(&self.buf, self.w, self.h).map_err(|e| e.to_string())?;
        self.prev_down = self.win.get_mouse_down(MouseButton::Left);
        Ok(self.win.is_open())
    }

    pub fn mouse(&self) -> Option<(f32, f32)> {
        self.win.get_mouse_pos(MouseMode::Clamp)
    }

    pub fn mouse_down(&self) -> bool {
        self.win.get_mouse_down(MouseButton::Left)
    }
}

/// Maps a key name such as "a", "5", "space", "left" to a window key.
pub fn key_from_name(n: &str) -> Option<K> {
    let n = n.to_ascii_lowercase();
    Some(match n.as_str() {
        "a" => K::A, "b" => K::B, "c" => K::C, "d" => K::D, "e" => K::E, "f" => K::F, "g" => K::G,
        "h" => K::H, "i" => K::I, "j" => K::J, "k" => K::K, "l" => K::L, "m" => K::M, "n" => K::N,
        "o" => K::O, "p" => K::P, "q" => K::Q, "r" => K::R, "s" => K::S, "t" => K::T, "u" => K::U,
        "v" => K::V, "w" => K::W, "x" => K::X, "y" => K::Y, "z" => K::Z,
        "0" => K::Key0, "1" => K::Key1, "2" => K::Key2, "3" => K::Key3, "4" => K::Key4,
        "5" => K::Key5, "6" => K::Key6, "7" => K::Key7, "8" => K::Key8, "9" => K::Key9,
        "space" => K::Space,
        "enter" => K::Enter,
        "escape" => K::Escape,
        "tab" => K::Tab,
        "backspace" => K::Backspace,
        "left" => K::Left,
        "right" => K::Right,
        "up" => K::Up,
        "down" => K::Down,
        "shift" => K::LeftShift,
        "ctrl" => K::LeftCtrl,
        _ => return None,
    })
}

/// Names of the built-in icons: heart, star, coin, key, sword, potion.
const ICONS: [(&str, [&str; 8]); 6] = [
    ("heart", [".rr..rr.", "rrwrrrrr", "rrrrrrrr", "rrrrrrrr", ".rrrrrr.", "..rrrr..", "...rr...", "........"]),
    ("star", ["...gg...", "...gg...", "gggggggg", ".gggggg.", "..gggg..", ".gg..gg.", ".g....g.", "........"]),
    ("coin", ["..kkkk..", ".kggggk.", "kgwggggk", "kgwggggk", "kggggggk", "kggggggk", ".kggggk.", "..kkkk.."]),
    ("key", ["..ggg...", ".g...g..", ".g...g..", "..ggg...", "...g....", "...gg...", "...g....", "........"]),
    ("sword", ["......pw", ".....pw.", "....pw..", "...pw...", "..pw....", ".lk.....", "lkl.....", "........"]),
    ("potion", ["..kkkk..", "...kk...", "..bbbb..", ".bwbbbb.", ".bbbbbb.", ".bbbbbb.", "..bbbb..", "........"]),
];

fn icon_grid(name: &str) -> Option<[&'static str; 8]> {
    ICONS.iter().find(|(n, _)| *n == name).map(|(_, g)| *g)
}

fn icon_color(ch: char) -> Option<u32> {
    match ch {
        'r' => Some(0xE03030),
        'g' => Some(0xF2C230),
        'w' => Some(0xFFFFFF),
        'k' => Some(0x202020),
        'b' => Some(0x3A7BD5),
        'p' => Some(0xA0A8B0),
        'l' => Some(0x8B5A2B),
        _ => None,
    }
}

/// Saves a picture of the whole primary screen to a PNG file (Windows only).
pub fn screenshot(path: &str) -> Result<(), String> {
    if !cfg!(windows) {
        return Err("screenshot works on Windows only for now".to_string());
    }
    let p = path.replace('\'', "''");
    let script = format!(
        "Add-Type -AssemblyName System.Windows.Forms,System.Drawing; \
         $b=[System.Windows.Forms.Screen]::PrimaryScreen.Bounds; \
         $bmp=New-Object System.Drawing.Bitmap $b.Width,$b.Height; \
         $g=[System.Drawing.Graphics]::FromImage($bmp); \
         $g.CopyFromScreen($b.Location,[System.Drawing.Point]::Empty,$b.Size); \
         $bmp.Save('{p}',[System.Drawing.Imaging.ImageFormat]::Png)"
    );
    let out = std::process::Command::new("powershell")
        .args(["-NoProfile", "-Command", &script])
        .output()
        .map_err(|e| e.to_string())?;
    if out.status.success() {
        Ok(())
    } else {
        Err(String::from_utf8_lossy(&out.stderr).trim().to_string())
    }
}

// Sends a prompt to an AI model over HTTP using the system curl program.
// Settings come from environment variables:
//   ANTHROPIC_API_KEY (or LACK_AI_KEY)  your API key
//   LACK_AI_MODEL                       model name, default claude-haiku-5-5
//   LACK_AI_URL                         API address, default Anthropic's messages endpoint
use std::io::Write;
use std::process::{Command, Stdio};

fn json_escape(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 2);
    out.push('"');
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if (c as u32) < 0x20 => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out.push('"');
    out
}

// Returns the first "text" value in a JSON reply, with escapes decoded.
fn first_text(body: &str) -> Option<String> {
    // Find the key "text" followed by a colon; a "text" value is not a key.
    let mut rest = None;
    let mut from = 0;
    while let Some(i) = body[from..].find("\"text\"") {
        let after = body[from + i + 6..].trim_start();
        if let Some(v) = after.strip_prefix(':') {
            rest = v.trim_start().strip_prefix('"');
            break;
        }
        from += i + 6;
    }
    let rest = rest?;
    let mut out = String::new();
    let mut chars = rest.chars();
    while let Some(c) = chars.next() {
        match c {
            '"' => return Some(out),
            '\\' => match chars.next()? {
                'n' => out.push('\n'),
                't' => out.push('\t'),
                'r' => out.push('\r'),
                'u' => {
                    let hex: String = (0..4).filter_map(|_| chars.next()).collect();
                    let code = u32::from_str_radix(&hex, 16).ok()?;
                    out.push(char::from_u32(code).unwrap_or('?'));
                }
                other => out.push(other),
            },
            c => out.push(c),
        }
    }
    None
}

// Sends one question and returns the reply.
pub fn ask(prompt: &str) -> Result<String, String> {
    chat(&[("user".to_string(), prompt.to_string())])
}

// Sends a whole conversation: each turn is (role, text), roles "user" or "assistant".
// The last turn must be from the user.
pub fn chat(turns: &[(String, String)]) -> Result<String, String> {
    let key = std::env::var("LACK_AI_KEY")
        .or_else(|_| std::env::var("ANTHROPIC_API_KEY"))
        .map_err(|_| "set the ANTHROPIC_API_KEY environment variable to use ai()".to_string())?;
    let url = std::env::var("LACK_AI_URL").unwrap_or_else(|_| "https://api.anthropic.com/v1/messages".to_string());
    let model = std::env::var("LACK_AI_MODEL").unwrap_or_else(|_| "claude-haiku-5-5".to_string());
    let messages: Vec<String> = turns
        .iter()
        .map(|(role, text)| format!("{{\"role\":{},\"content\":{}}}", json_escape(role), json_escape(text)))
        .collect();
    let body = format!(
        "{{\"model\":{},\"max_tokens\":1024,\"messages\":[{}]}}",
        json_escape(&model),
        messages.join(",")
    );
    let args: Vec<String> = vec![
        "-sS".into(),
        "-X".into(),
        "POST".into(),
        url,
        "-H".into(),
        format!("x-api-key: {key}"),
        "-H".into(),
        "anthropic-version: 2023-06-01".into(),
        "-H".into(),
        "content-type: application/json".into(),
        "--data-binary".into(),
        "@-".into(),
    ];
    let curl = if cfg!(windows) { "curl.exe" } else { "curl" };
    let mut child = Command::new(curl)
        .args(&args)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|e| format!("cannot run curl: {e}"))?;
    child
        .stdin
        .take()
        .ok_or("cannot open curl input")?
        .write_all(body.as_bytes())
        .map_err(|e| e.to_string())?;
    let out = child.wait_with_output().map_err(|e| e.to_string())?;
    let text = String::from_utf8_lossy(&out.stdout).to_string();
    if !out.status.success() {
        return Err(format!("request failed: {}", String::from_utf8_lossy(&out.stderr).trim()));
    }
    first_text(&text).ok_or_else(|| format!("no text in the AI reply: {text}"))
}

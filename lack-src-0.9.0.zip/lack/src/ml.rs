// A small neural network: one hidden layer with tanh, linear output, trained by
// gradient descent on mean squared error. Models are Lack lists of matrices.
use crate::interp::Value;
use std::cell::RefCell;
use std::rc::Rc;

type Mat = Vec<Vec<f64>>;

fn num(v: &Value) -> Result<f64, String> {
    match v {
        Value::Int(i) => Ok(*i as f64),
        Value::Float(f) => Ok(*f),
        _ => Err("numbers only".to_string()),
    }
}

fn to_mat(v: &Value) -> Result<Mat, String> {
    match v {
        Value::List(rows) => rows
            .borrow()
            .iter()
            .map(|r| match r {
                Value::List(c) => c.borrow().iter().map(num).collect(),
                _ => Err("expected a list of rows, like [[1, 2], [3, 4]]".to_string()),
            })
            .collect(),
        _ => Err("expected a list of rows, like [[1, 2], [3, 4]]".to_string()),
    }
}

fn from_mat(m: &[Vec<f64>]) -> Value {
    let rows: Vec<Value> = m
        .iter()
        .map(|r| Value::List(Rc::new(RefCell::new(r.iter().map(|x| Value::Float(*x)).collect()))))
        .collect();
    Value::List(Rc::new(RefCell::new(rows)))
}

fn matmul(a: &[Vec<f64>], b: &[Vec<f64>]) -> Result<Mat, String> {
    let k = b.len();
    if a.iter().any(|r| r.len() != k) {
        return Err("matrix sizes do not match".to_string());
    }
    let m = if k > 0 { b[0].len() } else { 0 };
    Ok(a.iter()
        .map(|row| {
            (0..m)
                .map(|j| (0..k).map(|t| row[t] * b[t][j]).sum::<f64>())
                .collect()
        })
        .collect())
}

fn transpose(a: &[Vec<f64>]) -> Mat {
    if a.is_empty() {
        return Vec::new();
    }
    (0..a[0].len()).map(|j| a.iter().map(|r| r[j]).collect()).collect()
}

fn add_bias(a: &[Vec<f64>], b: &[f64]) -> Mat {
    a.iter()
        .map(|r| r.iter().zip(b).map(|(x, y)| x + y).collect())
        .collect()
}

fn colsum(m: &[Vec<f64>]) -> Vec<f64> {
    if m.is_empty() {
        return Vec::new();
    }
    (0..m[0].len()).map(|j| m.iter().map(|r| r[j]).sum::<f64>()).collect()
}

fn tanh_all(m: &[Vec<f64>]) -> Mat {
    m.iter().map(|r| r.iter().map(|v| v.tanh()).collect()).collect()
}

fn rand_matrix(rows: usize, cols: usize, scale: f64, seed: &mut u64) -> Mat {
    let mut out = Vec::with_capacity(rows);
    for _ in 0..rows {
        let mut row = Vec::with_capacity(cols);
        for _ in 0..cols {
            *seed ^= *seed << 13;
            *seed ^= *seed >> 7;
            *seed ^= *seed << 17;
            let u = (*seed >> 11) as f64 / (1u64 << 53) as f64;
            row.push((u * 2.0 - 1.0) * scale);
        }
        out.push(row);
    }
    out
}

fn step(w: &mut Mat, dw: &[Vec<f64>], lr: f64) {
    for (wr, dr) in w.iter_mut().zip(dw) {
        for (a, b) in wr.iter_mut().zip(dr) {
            *a -= lr * b;
        }
    }
}

fn step_vec(b: &mut [f64], db: &[f64], lr: f64) {
    for (a, g) in b.iter_mut().zip(db) {
        *a -= lr * g;
    }
}

// Trains a network that maps each row of xs to the matching row of ys.
pub fn train(xs: &Value, ys: &Value, hidden: usize, epochs: usize, lr: f64) -> Result<Value, String> {
    let x = to_mat(xs)?;
    let t = to_mat(ys)?;
    if x.is_empty() || x.len() != t.len() {
        return Err("xs and ys need the same number of rows".to_string());
    }
    if hidden == 0 {
        return Err("hidden must be at least 1".to_string());
    }
    let n = x.len();
    let (d_in, d_out) = (x[0].len(), t[0].len());
    let mut seed: u64 = 42;
    let mut w1 = rand_matrix(d_in, hidden, 1.0 / (d_in as f64).sqrt(), &mut seed);
    let mut b1 = vec![0.0; hidden];
    let mut w2 = rand_matrix(hidden, d_out, 1.0 / (hidden as f64).sqrt(), &mut seed);
    let mut b2 = vec![0.0; d_out];
    for _ in 0..epochs {
        let h = tanh_all(&add_bias(&matmul(&x, &w1)?, &b1));
        let y = add_bias(&matmul(&h, &w2)?, &b2);
        let dy: Mat = y
            .iter()
            .zip(&t)
            .map(|(yr, tr)| yr.iter().zip(tr).map(|(a, b)| (a - b) * 2.0 / n as f64).collect())
            .collect();
        let dw2 = matmul(&transpose(&h), &dy)?;
        let db2 = colsum(&dy);
        let dh = matmul(&dy, &transpose(&w2))?;
        let dz: Mat = dh
            .iter()
            .zip(&h)
            .map(|(dr, hr)| dr.iter().zip(hr).map(|(d, hv)| d * (1.0 - hv * hv)).collect())
            .collect();
        let dw1 = matmul(&transpose(&x), &dz)?;
        let db1 = colsum(&dz);
        step(&mut w1, &dw1, lr);
        step_vec(&mut b1, &db1, lr);
        step(&mut w2, &dw2, lr);
        step_vec(&mut b2, &db2, lr);
    }
    Ok(Value::List(Rc::new(RefCell::new(vec![
        from_mat(&w1),
        from_mat(&[b1]),
        from_mat(&w2),
        from_mat(&[b2]),
    ]))))
}

// Runs a trained model on each row of xs and returns the outputs.
pub fn predict(model: &Value, xs: &Value) -> Result<Value, String> {
    let parts: Vec<Value> = match model {
        Value::List(l) => l.borrow().clone(),
        _ => return Err("the model must come from mlp_train".to_string()),
    };
    if parts.len() != 4 {
        return Err("the model must come from mlp_train".to_string());
    }
    let w1 = to_mat(&parts[0])?;
    let b1 = to_mat(&parts[1])?.remove(0);
    let w2 = to_mat(&parts[2])?;
    let b2 = to_mat(&parts[3])?.remove(0);
    let x = to_mat(xs)?;
    let h = tanh_all(&add_bias(&matmul(&x, &w1)?, &b1));
    let y = add_bias(&matmul(&h, &w2)?, &b2);
    Ok(from_mat(&y))
}

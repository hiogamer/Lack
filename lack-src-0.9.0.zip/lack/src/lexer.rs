#[derive(Debug, Clone, PartialEq)]
pub enum Tok {
    Int(i64),
    Float(f64),
    Str(String),
    Ident(String),
    Op(&'static str),
    Eof,
}

#[derive(Debug, Clone)]
pub struct Token {
    pub tok: Tok,
    pub line: usize,
    pub nl_before: bool,
}

const OPS: [&str; 33] = [
    "..=", "..", "==", "!=", "<=", ">=", "&&", "||", "+=", "-=", "*=", "/=", "%=", "->", "+", "-",
    "*", "/", "%", "<", ">", "=", "!", "(", ")", "{", "}", "[", "]", ",", ".", ":", "?",
];

pub fn lex(src: &str) -> Result<Vec<Token>, String> {
    let c: Vec<char> = src.chars().collect();
    let mut i = 0;
    let mut line = 1;
    let mut nl = false;
    let mut out = Vec::new();
    while i < c.len() {
        let ch = c[i];
        if ch == '\n' {
            line += 1;
            nl = true;
            i += 1;
        } else if ch.is_whitespace() {
            i += 1;
        } else if ch == '#' && c[i + 1..].starts_with(&['i', 'n', 'c', 'l', 'u', 'd', 'e']) {
            i += 8;
            out.push(Token { tok: Tok::Ident("include".into()), line, nl_before: nl });
            nl = false;
        } else if ch == '#' || (ch == '/' && c.get(i + 1) == Some(&'/')) {
            while i < c.len() && c[i] != '\n' {
                i += 1;
            }
        } else if ch.is_ascii_digit() {
            let s = i;
            while i < c.len() && (c[i].is_ascii_digit() || c[i] == '_') {
                i += 1;
            }
            let mut float = false;
            if i + 1 < c.len() && c[i] == '.' && c[i + 1].is_ascii_digit() {
                float = true;
                i += 1;
                while i < c.len() && c[i].is_ascii_digit() {
                    i += 1;
                }
            }
            let text: String = c[s..i].iter().filter(|x| **x != '_').collect();
            let tok = if float {
                Tok::Float(text.parse().map_err(|_| format!("line {line}: bad number"))?)
            } else {
                Tok::Int(text.parse().map_err(|_| format!("line {line}: bad number"))?)
            };
            out.push(Token { tok, line, nl_before: nl });
            nl = false;
        } else if ch.is_alphabetic() || ch == '_' {
            let s = i;
            while i < c.len() && (c[i].is_alphanumeric() || c[i] == '_') {
                i += 1;
            }
            let id: String = c[s..i].iter().collect();
            out.push(Token { tok: Tok::Ident(id), line, nl_before: nl });
            nl = false;
        } else if ch == '"' {
            i += 1;
            let mut s = String::new();
            loop {
                if i >= c.len() {
                    return Err(format!("line {line}: unterminated string"));
                }
                match c[i] {
                    '"' => {
                        i += 1;
                        break;
                    }
                    '\\' => {
                        i += 1;
                        match c.get(i) {
                            Some('n') => s.push('\n'),
                            Some('t') => s.push('\t'),
                            Some('"') => s.push('"'),
                            Some('\\') => s.push('\\'),
                            Some('{') => s.push('\u{1}'),
                            Some('}') => s.push('\u{2}'),
                            _ => return Err(format!("line {line}: bad escape")),
                        }
                        i += 1;
                    }
                    '\n' => return Err(format!("line {line}: unterminated string")),
                    x => {
                        s.push(x);
                        i += 1;
                    }
                }
            }
            out.push(Token { tok: Tok::Str(s), line, nl_before: nl });
            nl = false;
        } else {
            let rest: String = c[i..(i + 3).min(c.len())].iter().collect();
            match OPS.iter().find(|o| rest.starts_with(**o)) {
                Some(o) => {
                    i += o.len();
                    out.push(Token { tok: Tok::Op(o), line, nl_before: nl });
                    nl = false;
                }
                None => return Err(format!("line {line}: unexpected character '{ch}'")),
            }
        }
    }
    out.push(Token { tok: Tok::Eof, line, nl_before: true });
    Ok(out)
}

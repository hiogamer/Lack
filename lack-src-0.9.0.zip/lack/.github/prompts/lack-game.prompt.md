---
description: Write a complete Lack game or program
---

Write a complete Lack program for: ${input:idea}

Requirements:
- Follow docs/LACK-REFERENCE.md exactly. Use only built-ins listed there.
- Start from the example in the reference and keep the same style.
- Explain briefly how the controls work after the code.

---
applyTo: "**/*.lack,**/*.lc"
---

Write Lack code, not Python. Follow docs/LACK-REFERENCE.md.
Keep programs short. Use the examples/ folder as the style guide.
Use `while present()` loops for windows and `if button(...)` for buttons.

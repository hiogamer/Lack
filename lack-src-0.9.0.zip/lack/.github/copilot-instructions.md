# Lack project instructions

This project uses the Lack programming language (files end in .lack or .lc).
Lack is NOT Python, JavaScript or Rust. Before writing any Lack code, read
docs/LACK-REFERENCE.md and follow it exactly.

Key rules:
- Lack has no semicolons, no `and`/`or` (use && and ||), and no `match` or `try`.
- Strings use "{variable}" to insert values. Write \{ for a literal brace.
- Functions are `fn name(args) { ... }` and use `return`.
- Lists use list.push(x) and list.pop(). Maps are {key: value}.
- Graphics: open with window(w, h, title), then `while present() { ... }`.
- Examples are in the examples/ folder. Copy their style.
- When unsure whether a built-in exists, check the built-in table in the reference.
  Do not invent functions.

# Lack language reference

Lack is a programming language. Source files end in `.lack` or `.lc`.
Run a file with `lack run file.lack`. Lack is not Python, JavaScript or Rust.

## Basics

    name = "Lack"              # variables need no declaration
    age = 12                   # whole number (int)
    price = 3.5                # decimal number (float)
    ok = true                  # true / false
    nothing = nil              # nil = no value
    print("Hi {name}, age {age}")

- No semicolons. One statement per line.
- Comments start with `#` or `//`.
- Strings use double quotes. Inside a string, `{expression}` is replaced by its value.
  Write `\{` for a literal brace. Escapes: `\n` `\t` `\"` `\\`.
- Operators: `+ - * / %`, comparisons `== != < > <= >=`, logic `&& || not`.
  Use `&&`, `||` and `not`. There is no `and` / `or`.
- `x += 1`, `x -= 1`, `x *= 2`, `x /= 2`, `x %= 2` work.
- Division of two integers gives an integer: `10 / 4` is `2`. Use `10.0 / 4` for `2.5`.

## Conditions and loops

    if score > 10 {
        print("high")
    } else if score > 5 {
        print("medium")
    } else {
        print("low")
    }

    while lives > 0 {
        lives -= 1
        if lives == 2 { continue }
        if lives == 0 { break }
    }

    for i in 1..5 { print(i) }     # 1, 2, 3, 4 (end is excluded)
    for i in 1..=5 { print(i) }    # 1, 2, 3, 4, 5 (end is included)
    for item in my_list { print(item) }
    for key in my_map { print(key, my_map[key]) }   # loops over the keys
    for ch in "abc" { print(ch) }                   # loops over characters

Parentheses are optional around conditions. Braces `{ }` are required.

## Functions

    fn add(a, b) {
        return a + b
    }
    print(add(2, 3))           # 5

- A function with no `return` gives `nil`.
- Functions can be nested and can capture variables from outside (closures).
- Recursion works. Calls deeper than about 2000 levels are stopped with an error.

## Lists

    nums = [1, 2, 3]
    nums.push(4)               # add to the end
    last = nums.pop()         # remove and return the last item
    print(nums[0], nums[-1])   # negative index counts from the end
    nums[1] = 20
    print(len(nums), nums.len())

## Maps (key-value pairs)

    ages = {ann: 31, "ben": 27}      # bare names become string keys
    ages["cy"] = 40
    print(ages["ann"])
    print(ages.has("ben"), ages.keys(), ages.values())
    print(len(ages))

Reading a missing key is an error. Check with `ages.has("key")` first.

## Classes

    class Hero {
        name = "Hero"
        hp = 100
        fn hurt(amount) {
            hp -= amount          # fields are used directly inside methods
            if hp < 0 { hp = 0 }
        }
    }

    h = Hero()
    h.hurt(30)
    print(h.hp)                   # 70
    h.name = "Ann"                # fields can be set from outside

A class can define `fn init(...)`, which runs when the class is created with arguments.

## Built-in functions

| Function | What it does |
|---|---|
| `print(a, b, ...)` | Print values separated by spaces, then a new line |
| `len(x)` | Length of a list, map or string |
| `str(x)` | Convert to text |
| `int(x)` | Convert to a whole number (text or decimal) |
| `float(x)` | Convert to a decimal number |
| `sqrt(x)`, `abs(x)` | Square root, absolute value |
| `min(a, b)` | Smaller of two whole numbers |
| `type(x)` | Type name: int, float, bool, str, list, map, object, function |
| `push(list, x)` | Same as `list.push(x)` |
| `input("prompt")` | Read one line from the keyboard (text) |
| `random(lo, hi)` | Random whole number from lo to hi, both included |
| `sleep(ms)` | Wait this many milliseconds |
| `http_get(url)` | Download a web page as text (needs curl) |
| `links(html)` | List of the `href` values in HTML text |

Math: `sin_deg(x)` and `cos_deg(x)` take degrees.

## Graphics (2D)

    window(640, 480, "Title")          # open a window first
    while present() {                  # draw one frame; stops when the window closes
        clear(rgb(20, 20, 40))         # fill the background; rgb(red, green, blue), 0-255
        rect(x, y, width, height, rgb(80, 200, 255))
        circle(cx, cy, radius, rgb(255, 210, 0))
        text(20, 20, "Score: {score}", 24, rgb(255, 255, 255))   # x, y, text, size, color
        w = text_width("Score", 24)    # width in pixels
        image("logo.png", 10, 10)      # or image(path, x, y, width, height)
        if button(20, 100, 200, 44, "Start") { start() }   # true on the frame it is pressed
    }

- `present()` returns false after the window is closed, so loops should stop then.
- Keys: `key_down("left")` is true while held. Names: a-z, 0-9, space, enter, escape,
  tab, backspace, left, right, up, down, shift, ctrl.
- `mouse()` returns `[x, y]` inside the window, or `nil`. `mouse_down()` is true while the left button is held.
- Text uses Arial, DejaVu or Liberation Sans unless `font("file.ttf")` is called first.

## Controlling the keyboard and mouse

    key_press("enter")            # press and release a key
    type_text("hello")            # type text
    mouse_move(100, 200)          # screen coordinates
    mouse_click()                 # left click

## 3D graphics

    window(640, 480, "3D")
    while present() {
        clear(rgb(135, 190, 240))
        camera3d(0, 3, -8, 0, -10)     # x, y, z, yaw degrees, pitch degrees
        plane3d(0, 8, rgb(70, 140, 70))  # floor at y=0, half-size 8
        box3d(-1, 0, 0, 2, 2, 2, rgb(230, 80, 60))   # corner x,y,z; width, height, depth
        tri3d(0,0,0, 1,0,0, 0,1,0, rgb(255,255,0))   # three corners, then color
    }

Yaw 0 looks along +z. Positive pitch looks up. Save a frame with `save_image("shot.png")`.

## Sound

    tone(440, 500)                 # play 440 Hz for 500 ms in the background
    sound_wait()                   # wait until queued tones finish
    save_tone("beep.wav", 880, 300)  # write a WAV file

## Files and modules

    import util                    # loads util.lack or util/main.lack from the same folder
    #include "helpers.lack"       # loads a file by path (also: include "helpers.lack")
    import github.com/user/repo    # downloads a GitHub repo (needs git)

Imported code runs once and its functions and classes become visible.

## C library calls (Linux only at the moment)

    extern "libm.so.6" fn cos(float) -> float
    print(cos(0.0))

Parameter and return types: `int`, `float`, `str`, or no return type for nothing.

## Things Lack does not have yet

- No static type checking: wrong types are found when the program runs.
- No `match` or `switch` statement. Use `if` / `else if`.
- No `try` / `catch`. An error stops the program and shows the line number.
- No default function arguments, no keyword arguments, no `async`.
- No slicing like `text[1:3]`. Use loops or `text[i]` with indexes.
- No file reading or writing except `save_tone` and `save_image`.

## Complete example

    window(480, 320, "Clicker")
    score = 0
    while present() {
        clear(rgb(18, 18, 30))
        text(20, 20, "Score: {score}", 28, rgb(255, 255, 255))
        if button(20, 100, 200, 44, "Click") {
            score += 1
            tone(440 + score * 10, 60)
        }
        if key_down("escape") { break }
    }
    print("Final score: {score}")

#!/bin/sh
# Builds the lack binary on macOS. Needs Rust from https://rustup.rs
set -e
cargo build --release
echo "Built: $(pwd)/target/release/lack"
echo "Run it with: ./target/release/lack run examples/features.lack"

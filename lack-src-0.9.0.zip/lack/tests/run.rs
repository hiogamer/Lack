use std::process::Command;

fn run(src: &str) -> (String, String, bool) {
    let dir = std::env::temp_dir().join(format!("lack_t_{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let f = dir.join(format!("t{}.lack", src.len() + src.bytes().map(|b| b as usize).sum::<usize>()));
    std::fs::write(&f, src).unwrap();
    let o = Command::new(env!("CARGO_BIN_EXE_lack")).arg("run").arg(&f).output().unwrap();
    (
        String::from_utf8_lossy(&o.stdout).into(),
        String::from_utf8_lossy(&o.stderr).into(),
        o.status.success(),
    )
}

#[test]
fn hello() {
    assert_eq!(run("fn greet(name) {\n print(\"Hello \" + name)\n}\ngreet(\"World\")\n").0, "Hello World\n");
}

#[test]
fn inclusive_exclusive_ranges() {
    assert_eq!(run("for i in 1..4 { print(i) }\nfor i in 1..=2 { print(i) }").0, "1\n2\n3\n1\n2\n");
}

#[test]
fn class_fields_in_methods() {
    let src = "class P {\n health = 100\n fn hit(a) {\n health -= a\n }\n}\np = P()\np.hit(30)\nprint(p.health)\n";
    assert_eq!(run(src).0, "70\n");
}

#[test]
fn recursion_and_closures() {
    let src = "fn fib(n) {\n if n < 2 { return n }\n return fib(n-1) + fib(n-2)\n}\nprint(fib(20))\nfn mk() {\n c = 0\n fn inc() {\n c += 1\n return c\n }\n return inc\n}\nf = mk()\nf()\nprint(f())\n";
    assert_eq!(run(src).0, "6765\n2\n");
}

#[test]
fn lists_and_strings() {
    let src = "a = [1, 2]\na.push(3)\nprint(a, len(a), a[-1])\nprint(\"ab\".upper() + \"!\")\nprint(10 / 4, 10.0 / 4, 7 % 3)\n";
    assert_eq!(run(src).0, "[1, 2, 3] 3 3\nAB!\n2 2.5 1\n");
}

#[test]
fn control_flow() {
    let src = "i = 0\nwhile true {\n i += 1\n if i == 2 { continue }\n if i > 4 { break }\n print(i)\n}\n";
    assert_eq!(run(src).0, "1\n3\n4\n");
}

#[test]
fn errors_have_line_numbers() {
    let (_, e, ok) = run("x = 1\nprint(y)\n");
    assert!(!ok);
    assert!(e.contains("line 2") && e.contains("undefined variable 'y'"), "{e}");
    let (_, e, ok) = run("print(1 / 0)");
    assert!(!ok && e.contains("division by zero"), "{e}");
}

#[test]
fn string_interpolation() {
    let src = "name = \"Lack\"\nv = 2\nprint(\"Hi {name} v{v + 1}!\")\nprint(\"brace \\{ok\\}\")\n";
    assert_eq!(run(src).0, "Hi Lack v3!\nbrace {ok}\n");
}

#[test]
fn maps() {
    let src = "m = {a: 1, \"b\": 2}\nm[\"c\"] = 3\nprint(m, len(m), m.has(\"a\"), m.keys())\nfor k in m { print(k, m[k]) }\n";
    assert_eq!(run(src).0, "{a: 1, b: 2, c: 3} 3 true [\"a\", \"b\", \"c\"]\na 1\nb 2\nc 3\n");
}

#[test]
fn deep_recursion_is_an_error_not_a_crash() {
    let (_, e, ok) = run("fn f(n) { return f(n + 1) }\nf(0)\n");
    assert!(!ok && e.contains("stack overflow"), "{e}");
}

#[test]
fn import_and_include() {
    let dir = std::env::temp_dir().join(format!("lack_imp_{}", std::process::id()));
    std::fs::create_dir_all(dir.join("lack_modules/mathx")).unwrap();
    std::fs::write(dir.join("util.lack"), "fn twice(x) { return x * 2 }\nprint(\"util loaded\")\n").unwrap();
    std::fs::write(dir.join("lack_modules/mathx/main.lack"), "fn sq(x) { return x * x }\n").unwrap();
    std::fs::write(dir.join("main.lack"), "import util\n#include \"util.lack\"\n#include <mathx>\nprint(twice(4), sq(3))\n").unwrap();
    let o = Command::new(env!("CARGO_BIN_EXE_lack")).arg("run").arg(dir.join("main.lack")).output().unwrap();
    assert!(o.status.success(), "{}", String::from_utf8_lossy(&o.stderr));
    assert_eq!(String::from_utf8_lossy(&o.stdout), "util loaded\n8 9\n");
}

#[test]
fn missing_module_is_clear_error() {
    let (_, e, ok) = run("import openai\n");
    assert!(!ok && e.contains("module 'openai' not found"), "{e}");
}

#[test]
fn ffi_calls_c_library() {
    let src = "extern \"libm.so.6\" fn cos(float) -> float\nextern \"libc.so.6\" fn strlen(str) -> int\nextern \"libc.so.6\" fn getpid() -> int\nprint(cos(0.0))\nprint(strlen(\"hello\"))\nprint(getpid() > 0)\n";
    assert_eq!(run(src).0, "1.0\n5\ntrue\n");
}

#[test]
fn http_get_and_links() {
    let dir = std::env::temp_dir().join(format!("lack_web_{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let page = dir.join("page.html");
    std::fs::write(&page, "<a href=\"https://a.example/x\">x</a> <a href='/rel'>y</a>").unwrap();
    let src = format!("html = http_get(\"file://{}\")\nprint(links(html))\n", page.display());
    assert_eq!(run(&src).0, "[\"https://a.example/x\", \"/rel\"]\n");
}

#[test]
fn int_min_div_neg_one_is_error_not_panic() {
    let (_, e, ok) = run("x = -9223372036854775807 - 1\nprint(x / -1)\n");
    assert!(!ok && e.contains("integer overflow"), "{e}");
}

#[test]
fn links_decode_html_entities() {
    let dir = std::env::temp_dir().join(format!("lack_ent_{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let page = dir.join("e.html");
    std::fs::write(&page, "<a href=\"p?q=1&amp;r=2\">x</a>").unwrap();
    let src = format!("print(links(http_get(\"file://{}\")))\n", page.display());
    assert_eq!(run(&src).0, "[\"p?q=1&r=2\"]\n");
}

#[test]
fn input_and_random() {
    let dir = std::env::temp_dir().join(format!("lack_in_{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let f = dir.join("in.lack");
    std::fs::write(&f, "name = input(\"who? \")\nprint(\"hi \" + name)\nn = random(1, 6)\nprint(n >= 1 && n <= 6)\n").unwrap();
    let mut child = std::process::Command::new(env!("CARGO_BIN_EXE_lack"))
        .arg("run").arg(&f)
        .stdin(std::process::Stdio::piped()).stdout(std::process::Stdio::piped())
        .spawn().unwrap();
    use std::io::Write;
    child.stdin.take().unwrap().write_all(b"Ann\n").unwrap();
    let o = child.wait_with_output().unwrap();
    assert_eq!(String::from_utf8_lossy(&o.stdout), "who? hi Ann\ntrue\n");
}

#[test]
fn text_width_and_wav_export_headless() {
    let dir = std::env::temp_dir().join(format!("lack_snd_{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let wav = dir.join("beep.wav");
    let src = format!(
        "print(text_width(\"hello\", 16) > 20)\nsave_tone(\"{}\", 440, 100)\n",
        wav.display()
    );
    let (out, e, ok) = run(&src);
    assert!(ok, "{e}");
    assert_eq!(out, "true\n");
    // 44-byte WAV header + 4410 samples * 2 bytes
    assert_eq!(std::fs::metadata(&wav).unwrap().len(), 44 + 8820);
    let bytes = std::fs::read(&wav).unwrap();
    assert_eq!(&bytes[0..4], b"RIFF");
    assert_eq!(&bytes[8..12], b"WAVE");
}

#[test]
fn image_missing_file_is_clear_error() {
    let (_, e, ok) = run("window(10, 10, \"x\")\nimage(\"no_such.png\", 0, 0)\n");
    assert!(!ok && (e.contains("cannot load image") || e.contains("window")), "{e}");
}

# Lack 0.8.0

Lack is an early-stage programming language written in Rust. This version is a
tree-walking interpreter with a REPL. Native compilation, static type inference,
and the AI/game libraries are not built yet.

## Install (needs Rust: https://rustup.rs)

    cargo build --release
    # binary: target/release/lack  (Windows: target\release\lack.exe)

## Use

    lack                      # interactive REPL
    lack run examples/hello.lack
    lack examples/fib.lack    # same as run
    lack new MyProject        # creates MyProject/src/main.lack
    lack run                  # runs src/main.lack or main.lack in the current folder

## Language tour

    name = "Lack"                      # variables, no declarations
    print("Hello {name}!")            # string interpolation; \{ for a literal brace
    fn add(a, b) { return a + b }     # functions and closures
    for i in 1..=5 { print(i) }       # 1..5 excludes end; 1..=5 includes it
    nums = [1, 2, 3]; nums.push(4)    # lists
    m = {a: 1, "b": 2}                # maps
    m["c"] = 3; print(m.keys())
    class Player {                    # classes: fields and methods
        health = 100
        fn damage(n) { health -= n }
    }
    p = Player(); p.damage(30); print(p.health)   # 70
    if x > 1 { ... } else if ... { ... } else { ... }
    while cond { ... break / continue }

Errors print the line number and exit with status 1.

## Imports

    import util                      # finds util.lack, util/main.lack, lack_modules/util/..., or ~/.lack/packages/util/...
    #include "lib/helpers.lack"      # run a file by path (runs once even if imported twice)
    #include <mathx>                 # angle-bracket form, same lookup as import
    import github.com/user/repo      # clones with git into ~/.lack/cache, then loads its main.lack
    import github.com/user/repo/sub/file

Imported files run in the global scope, so their functions and classes are visible afterwards.
Missing modules report every place that was searched. There is no package registry yet: to use a
package, put its folder in lack_modules/ next to your program.

## Calling C libraries (FFI, Linux)

    extern "libm.so.6" fn cos(float) -> float
    extern "libc.so.6" fn strlen(str) -> int
    print(cos(0.0))          # 1.0
    print(strlen("hi"))      # 2

Parameter and return types: int, float, str (or void). Any C library can be loaded this way.

## Web

    page = http_get("https://example.com")   # uses the curl command
    for link in links(page) { print(link) }   # lists href values

## Input and random numbers

    name = input("Your name: ")     # reads a line from the keyboard
    roll = random(1, 6)             # whole number from 1 to 6 (inclusive)

## Example game

    lack run examples/game.lack     # LACK DUNGEON: a text battle game

## Windows, macOS and Linux

Screens, keyboard and mouse work on all three systems.

    window(640, 480, "My Game")       # open a window (Windows, macOS, Linux with a display)
    while present() {                 # draw a frame; stops when the window is closed
        clear(rgb(20, 20, 40))        # colors are rgb(red, green, blue), 0-255
        rect(10, 10, 100, 50, rgb(80, 200, 255))   # x, y, width, height, color
        circle(200, 120, 30, rgb(255, 210, 0))     # x, y, radius, color
        if key_down("left") { print("left!") }    # keys: a-z, 0-9, space, enter, escape, tab, arrows, shift, ctrl
        m = mouse()                   # [x, y] inside the window, or nil
        if mouse_down() { print("clicking") }
    }

Control the computer (affects the whole screen, not just the window):

    key_press("enter")                # press and release a key
    type_text("hello")                # type text
    mouse_move(100, 200)              # move the mouse to screen coordinates
    mouse_click()                     # left click
    sleep(500)                        # wait 500 milliseconds

Examples: `examples/catch.lack` (arrow keys + Escape to quit) and `examples/gfx_smoke.lack`.

## Text, images and buttons

    font("C:/Windows/Fonts/arial.ttf")     # optional; Arial/DejaVu/Liberation is found automatically
    text(20, 20, "Score: 10", 24, rgb(255, 255, 255))   # x, y, text, font size in pixels, color
    w = text_width("Score: 10", 24)        # width in pixels, for centering
    image("logo.png", 10, 10)              # PNG, JPEG, etc. (cached after first load)
    image("logo.png", 10, 10, 64, 64)      # scaled to 64x64
    if button(20, 100, 160, 40, "Start") { print("clicked") }   # true on the frame it is pressed

## Sound

    tone(440, 500)          # play a 440 Hz tone for 500 ms (plays in the background)
    sound_wait()            # wait until all queued tones finish
    save_tone("beep.wav", 880, 300)    # write a WAV file (16-bit mono, 44.1 kHz)

Sound needs an audio output device. Images and sound files are read from disk when used.

## 3D graphics

    camera3d(x, y, z, yaw, pitch)    # camera position; angles in degrees (yaw 0 looks along +z, positive pitch looks up)
    plane3d(y, half, color)          # flat floor centered on (0, y, 0)
    box3d(x, y, z, w, h, d, color)   # solid box with its corner at (x, y, z)
    tri3d(x1,y1,z1, x2,y2,z2, x3,y3,z3, color)   # one triangle
    s = sin_deg(45)                  # sine and cosine take degrees
    save_image("shot.png")           # save the current frame as a PNG

3D is drawn in software (no graphics card needed), so it runs on any computer. It has a depth
buffer and simple lighting. Example: `examples/cube3d.lack`.

## Suggestions and bugs

Email suggestions and bug reports to huguiito.serna@gmail.com.

## Tests

    cargo test

Runs the automated tests in tests/run.rs.

## Project layout

    src/lexer.rs    tokenizer
    src/parser.rs   parser (builds AST)
    src/ast.rs      syntax tree types
    src/interp.rs   interpreter and runtime values
    src/main.rs     CLI (run, new, REPL)
    examples/       sample programs
    tests/run.rs    automated tests

## Known limits

- Values are dynamically typed; no static type checking yet.
- Only int, float and str types for FFI; no structs, callbacks or variadic C functions.
- http_get needs the curl command installed.
- 3D is software-rendered: simple solid shapes, no textures, no models from files, no GPU.
- Sound is generated tones and WAV export only; no music file playback yet.
- Screen and keyboard control on Linux needs an X11 display.
- No native code generation, no GPU/SIMD, no package manager, no standard library beyond the built-ins (print, len, str, int, float, sqrt, abs, push, type, min).
- Recursion depth is capped at 2000 calls.
